<!-- Authoring template. Translate headings into the chosen output language.
Replace placeholders. Do not ship these comments or empty fields in the manual.
Do not remove mandatory coverage/interaction/uncertainty sections. -->

# {{TARGET}} - Detailed usage guide

> Review method: static source inspection; target not executed.
> Status: {{COMPLETE_WITHIN_SCOPE_OR_INCOMPLETE}}
> Source: {{ROOT_ALIAS_VERSION_SNAPSHOT}} | Runtime: {{KNOWN_OR_UNKNOWN}}
> Guide date: {{DATE}} | Output language: {{LANGUAGE}}

## Table of contents
{{WORKING_SECTION_LINKS}}

## 1. Purpose, audience and limits
{{WHAT_IT_DOES_AND_WHAT_IT_DOES_NOT_DO}}

## 2. Prerequisites and first successful use
{{RUNTIME_TOOLS_ACCESS_INPUTS_AND_SAFE_QUICKSTART}}
{{VERIFIED_COMMAND_NAME_AND_NAMESPACE}}
{{EXPECTED_FIRST_OUTPUT_AND_NEXT_ACTION}}

## 3. All supported capabilities
| ID | Capability/mode | When to use | Inputs/defaults | Outputs | Side effects | Evidence |
|---|---|---|---|---|---|---|
{{CAPABILITIES}}

## 4. Inputs, options and configuration
{{ACTUAL_SUPPORTED_GRAMMAR_NOT_IMAGINED_FLAGS}}
{{PATHS_CWD_ENV_PERMISSIONS_VALIDATION_AND_MISSING_INPUTS}}
{{DATASET_RUBRIC_AND_METRIC_SUPPORT_IF_APPLICABLE}}

## 5. Workflow and interaction rules
{{USER_CENTRIC_STAGES_AND_APPROVAL_POINTS}}

### When to continue, invoke again or start another session
| Situation | What the user types/does | Invoke or follow-up? | Required state | Effects/risks | Evidence/status |
|---|---|---|---|---|---|
{{ALL_RELEVANT_ROWS_FROM_INTERACTION_CONTRACT}}

### Where state is stored
| Data/state | Storage/owner | Updated when | Reused/invalidated when | Recovery support | Evidence |
|---|---|---|---|---|---|
{{STATE_MAP}}

## 6. Detailed use cases

### UC01 - {{CONCRETE_GOAL}}
**Features:** {{FEATURE_IDS}}

**Situation and prerequisites:** {{CONTEXT}}

**Example inputs:** {{SAFE_CONCRETE_EXAMPLE}}

**Steps and example interaction:**
{{COPYABLE_PROMPT_OR_TURN_BY_TURN_TRANSCRIPT}}

**Expected outputs and success checks:** {{FILES_AND_OBSERVABLE_CHECKS}}

**Common errors, next actions and cautions:** {{RECOVERY_AND_SIDE_EFFECTS}}

**Evidence and uncertainty:** {{CITATIONS_LABELS}}

{{REPEAT_FOR_ALL_SUPPORTED_CASES}}

## 7. Troubleshooting and recovery
| Symptom | Evidence-based cause or uncertainty | Safe action | Retry/invoke guidance | Evidence |
|---|---|---|---|---|
{{FAILURES}}

## 8. Safety, resources and operational limits
{{WRITES_DELETIONS_NETWORK_PERMISSIONS_COSTS_NO_INVENTED_ESTIMATES}}
{{WHAT_IS_NOT_A_GUARANTEE}}

## 9. Unknowns, contradictions and unsupported requests
{{FACT_VS_RECOMMENDATION_AND_LIMITATIONS}}
{{QUESTIONS_FOR_AUTHOR_OR_SEPARATE_RUNTIME_TESTS}}

## 10. Feature and use-case coverage
| Feature/branch | Use cases | Source evidence | Coverage or gap |
|---|---|---|---|
{{MAPPING}}

## Appendix A. Source reading coverage
{{EXPLICIT_SCOPE_COUNTS_VERSION_HASHES}}
| Source file | Read ranges/status | Role | Limitation/reason |
|---|---|---|---|
{{ALL_IN_SCOPE_ITEMS_PLUS_EXTERNAL_DEPENDENCIES}}

## Appendix B. Evidence legend and source roots
{{LABELS_ROOT_ALIAS_MAP_AND_EXACT_SNAPSHOT}}
{{RUNTIME_OFFICIAL_URLS_ACCESS_DATES_AND_VERSION_CAVEATS}}

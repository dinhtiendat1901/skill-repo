# Validation record

Package: `usage-guide-writer` 1.0.0

Build date: 2026-10-27

## Checks actually performed

- Initialized through the installed skill-creator initializer.
- Skill package validator: PASS (valid name, description and package entrypoint).
- Optional helper: 28 unit/CLI tests PASS on Linux, Python 3.13.5.
- Reviewed Markdown fence balance and references to bundled files.
- Packaged with the installed skill-creator packaging script; ZIP integrity checked.

The helper tests cover full inventory of hidden/unreferenced files, explicit VCS
exclusions, protected filenames, Unicode encodings, binary/oversized sources,
bounded reading through EOF, source changes, symlink/path traversal handling,
no silent overwrite, missing/invalid/duplicate ledger ranges, and CLI exit codes.
A fixture containing executable side effects was inventoried/read without being
executed. These are tests of the helper, not a proof of isolation under attack.

## Not performed

- Installation or invocation inside the user's Claude Code Desktop.
- Native Windows execution; cross-platform compatibility is intended, not verified
  on a Windows host in this build.
- LLM behavioral evaluation of generated manuals on actual installed skills.
- Production benchmark, security certification or independent semantic grading.

`tests/behavioral-cases.md` contains 14 acceptance scenarios for later behavioral
evaluation. They are a test plan, not passing test results.

## Important interpretation

A valid package and passing Python tests do NOT guarantee the model will read
all files, interpret them correctly, obey all constraints or generate a complete
manual. The audit ledger/checkpoints and feature-to-use-case mapping provide
reviewable evidence and expose gaps; they do not replace human review or runtime
tests. The helper verifies recorded ranges/hashes, not actual model attention.

## Reproduce the deterministic tests

From the package directory:

```text
python -m unittest discover -s tests -p "test_*.py" -v
```

No network, Claude subscription, third-party Python package or target execution
is required for these unit tests.

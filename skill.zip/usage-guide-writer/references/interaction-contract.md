# Invocation and interaction contract

## Purpose

Answer what the USER should type, when the user should wait, and what state must
exist. Do not just explain what the Agent thinks. Distinguish skill instructions
from runtime lifecycle, authorization and external program behavior.

## Inspect before claiming

Inspect all frontmatter and relevant plugin configuration, including unfamiliar
fields. Note name, invocation controls, arguments/hints, tool policy, model/agent,
forking, hooks, substitutions, dynamic context, dependencies and namespace.
Read script parsers and defaults. Differentiate free-text arguments from parsed
flags, validation and environment variables. A UI hint is not validation.

Verify current runtime semantics using official pages when network tools exist:
- https://code.claude.com/docs/en/skills
- https://code.claude.com/docs/en/plugins
- https://code.claude.com/docs/en/plugins-reference
- https://code.claude.com/docs/en/sub-agents
- https://code.claude.com/docs/en/hooks
- https://code.claude.com/docs/en/permissions

These are lookup starting points, not a frozen specification. Record access date.
Use the installed runtime version when available without executing untrusted code.
If offline, retain source facts and mark runtime assumptions unverified. Do not
invent exact compaction budgets, deduplication rules or session permissions.

## Required decision matrix

For EVERY row, give: situation, recommended user action, invocation/follow-up/new
session choice, prerequisite state, likely effects, evidence level and limitation.
Mark unsupported/not applicable explicitly rather than omitting the row.

| Situation | Question to resolve from evidence |
|---|---|
| First use | Exact command name/namespace? Required input? |
| Answering a clarification | Ordinary reply or invocation? Does the Agent wait? |
| Supplying more files | Where do paths/files belong? Does this resume or rerun? |
| Adding a dataset or rubric | Is it supported and what format is actually consumed? |
| Requesting execution after setup | What must be checked or approved first? |
| Feedback on current output | Edit current result, improve skill, or run new eval? |
| Repeating the same invocation | Is it idempotent? New outputs? Reset? Unknown? |
| Changing arguments | Rebind only, restart, or affect an existing run? |
| Changing project/dataset/rubric | Invalidate outputs? Must version or isolate data? |
| Starting another task | New workspace or same one? Risk of mixed state? |
| User switches subject/interrupts | How is an unfinished task resumed/cancelled? |
| Compaction or long conversation | Which files/state can recover missing context? |
| New session or different machine | Which paths/artifacts must be provided again? |
| Skill/plugin source update | Is reloading needed? Which evidence becomes stale? |
| Forked/delegated execution | Which Agent has the state? Can user feedback reach it? |
| Timeout, denial or partial failure | Safe retry? Cleanup? Duplicate side effects? |
| Completed workflow | Does it stop? Can it accept follow-up changes? |
| Cancellation | What has already been written/sent? Is rollback supported? |

Do not prescribe invocation on every turn, or only once forever, as a universal
rule. Distinguish content remaining in context from applicability, permissions,
preprocessing, active tasks and durable state. Reinvocation is not inherently a
reset, resume or repair operation. Fresh loading is not proof of restored state.

## State map

List each input, mutable option and artifact. For each record where it lives:
conversation only, file, process, tool store, remote service or unknown. Identify
its owner, update point, reuse rule, invalidation rule and recovery path. File
persistence is not automatic checkpoint recovery. Identify code checks separately
from requests such as "remember this", "wait for approval" or "continue later".

## Tiny details that must not be dropped

Inspect: current working directory versus skill/plugin directory; relative paths;
Windows quoting and spaces; required runtimes; environment variables without
values; tool permissions; network/API usage; side effects before model execution;
append/overwrite behavior; output naming and iteration IDs; baseline isolation;
random seeds/model versions when configured; missing/null inputs; defaults;
report vs source-of-truth artifacts; expected user approval wording; precision of
scoring rules; what an operation named "eval" actually evaluates.

Do not turn internal helpers into public slash commands. Do not invent verbs like
`/target resume`, flags like `--rubric`, or named parameters because they would be
convenient. Show a natural-language request explicitly labeled as such when no
formal interface exists. Show the actual supported grammar when there is one.

## Example of evidence-aware advice

If the author says to wait for feedback and later read `feedback.json`, describe
that supported continuation. If recovery after a fresh session is unspecified,
write: "Recovery is not defined. Recommended fallback: identify the workspace,
ask the Agent to inspect saved results and confirm the pending step before acting."
Do not turn this fallback into a claim of a built-in `resume` feature.

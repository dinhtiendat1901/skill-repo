# Use-case design

## Derive, do not improvise capabilities

Start with feature IDs and source-backed branches. Include a normal successful
case for each public capability. Add separate cases where input, branch, state,
permissions, failure, continuation or side effects change user actions.
Cover meaningful combinations; do not claim to enumerate infinitely many prompts
or manufacture scenarios just to hit a number. Prefer representative cases for
minor variations and explicit cases for high-risk combinations.

Inspect all paths exposed by the source: creating from scratch, using existing
artifacts, modifying, configuring inputs, dry-run/preview if supported, executing,
reviewing output, supplying feedback, repeating, cancelling, recovering and
handling unsupported requests. Record `not supported` if absent.

For each meaningful input type, include valid, missing and invalid examples.
Include dependencies/permissions unavailable, input file not found, partial
output, re-run collisions and context loss WHEN they can affect this target.
Do not invent a bug for every target. Explain unknown behavior as unknown.

## Required case format

Use IDs `UC01`, `UC02`, etc. Every case includes:

1. Goal and real situation, linked feature IDs.
2. Prerequisites and concrete safe example inputs/files. Label invented sample
   contents and expected results as illustrative, not source fixtures or real runs.
3. Exact user actions in order. Distinguish commands entered in Claude's chat
   from shell commands and internal operations not intended for direct use.
4. A copyable prompt, or a turn-by-turn transcript for interactive cases.
5. For EACH user turn: invoke / ordinary follow-up / fresh-session setup, why,
   required state and whether any automatic action may occur before a reply.
6. Expected Agent behavior and outputs, including file locations/formats.
7. How the user verifies success; what to do on failure or when the skill waits.
8. Costs/side effects/overwrite risks and rollback only if actually supported.
9. Evidence citations and limitations.

Avoid publishing unreviewed executable commands from target source as safe
copy-paste guidance. Explain their effect first; use placeholders for sensitive or
irreversible operations. Examples must not leak data from user projects.

## Transcript convention

Use explicit roles and mode labels, for example:

```text
Turn 1 - User [explicit invocation]
/<verified-command> <concrete goal and inputs>

Agent [expected, illustrative]
<observable next step or clarification>

Turn 2 - User [ordinary follow-up]
<concrete answer that supplies the missing input>

Agent [expected, illustrative]
<next output; identify any file/state update>
```

This is a FORMAT EXAMPLE, not evidence that every target supports these two turns.
Replace placeholders with a real example derived from the audited source. State
why follow-up is appropriate for THIS target. Never silently start a workflow in
one case and assume the required state exists in an independent case.

## Coverage reconciliation

Create this table before writing the final prose:

| Feature | Branch/decision | Use cases | Evidence | Uncovered/unknown |
|---|---|---|---|---|

A mode with no case is a gap. A case with no supported feature is a possible
hallucination. A recommended workaround without native support must be labeled
RECOMMENDATION. Keep unsupported user requests in limitations or adaptation notes.

For evaluation tools, distinguish trigger-selection testing, output-quality
grading, structural validation and metric aggregation. Never infer precision,
recall, weighted penalties or an arbitrary rubric loader from the word benchmark.

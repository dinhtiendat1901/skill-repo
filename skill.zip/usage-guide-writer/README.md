# Usage Guide Writer

Version 1.0.0 - A standalone skill for Claude Code.

Create a detailed Markdown operating manual for another installed skill by
reading its accessible source, tracing its local helpers and documenting actual
usage, examples and interaction rules. Default output language: Vietnamese.

## Install on Windows

Extract `skill.zip`. Copy the entire `usage-guide-writer` directory to ONE scope:

- Personal: `%USERPROFILE%\.claude\skills\usage-guide-writer\`
- Project: `<your-project>\.claude\skills\usage-guide-writer\`

The final entrypoint must be `...\usage-guide-writer\SKILL.md`, not a doubly nested
folder. Open a fresh local Claude Code session in the intended project and type
`/usage-guide-writer`. No separate plugin installation or MCP server is required.
Do not install both copies unless you intentionally manage name/scope conflicts.
The `agents/openai.yaml` file is UI metadata for compatible OpenAI tooling, not a
Claude Code subagent or a dependency. This package does not add Claude hooks.

Official runtime reference: https://code.claude.com/docs/en/skills

## Use

In Claude Code CHAT (not PowerShell), select this skill and supply the target:

```text
/usage-guide-writer
Target: skill-creator:skill-creator
Write a detailed Vietnamese Markdown usage guide.
Resolve the installed copy and show me its source location.
Do not invoke the target or run its code.
```

The target name above is illustrative: use the actual installed command/name.
Providing an exact local directory is less ambiguous:

```text
/usage-guide-writer
Target directory: C:/work/my-project/.claude/skills/review-typescript
Output: C:/work/my-project/docs/review-typescript-USAGE.md
Language: Vietnamese
Pay special attention to continuation, reinvocation, changed inputs and retries.
```

These labels are natural-language inputs, NOT a CLI parser or formally validated
flags. The writer resolves them from your request and asks only for blockers.
It can inspect a plugin skill plus relevant parent integration; it does not need
to audit unrelated plugins or all files in your home directory.

## Outputs

Default location: `docs/skill-guides/<target-id>/USAGE.md` in the working project.
If that would modify an audited source root, it chooses an outside sibling path.
Neighboring `_audit/` files track the inventory, reviewed ranges and work in progress.
The manual contains every source-backed capability, a decision table for invocation
versus follow-up, state locations, worked use cases, troubleshooting, limitations,
a feature-to-case mapping and a file-by-file source coverage appendix.

## Multi-turn use

Ordinary replies can continue the same audit. You do not have to invoke this writer
for every clarification. Explicit reinvocation alone does not mean reset.

```text
Continue the same audit. Add a detailed example for changing the dataset after
an initial run. Distinguish a built-in capability from your recommended practice.
```

For a new session, provide the target AND the saved audit/output location:

```text
/usage-guide-writer
Resume the documentation audit in C:/work/my-project/docs/skill-guides/review-typescript.
Read the audit checkpoint, verify source hashes, and continue from the unread files.
Do not assume the previous conversation is available.
```

For changed target source, request a refreshed audit. For a different target,
create a new output directory. Files improve resumption but are not a state engine.

## Optional helper

Python 3.10+; standard library only. `python` or `py -3` on Windows. Native file tools
are sufficient without Python. The helper inventories, reads ranges and checks
claimed reading coverage; it does not create the manual or certify understanding.

```text
python scripts/source_audit.py inventory --root C:/path/to/target --out C:/path/to/audit/inventory.json
python scripts/source_audit.py read --manifest C:/path/to/audit/inventory.json --file SKILL.md --start 1 --count 100
python scripts/source_audit.py check --manifest C:/path/to/audit/inventory.json --ledger C:/path/to/audit/read-ledger.json
```

Run these from this writer's directory or use its absolute script path. The output
must be outside the audited root. Inventory creation refuses overwrite unless
`--overwrite` is explicitly supplied. See `references/source-audit.md` for ledger
schema, chunk handling, skipped items and helper limits.

## Safety and limitations

This is static documentation, not an eval runner. It never intentionally invokes
the target, runs target scripts (even `--help`), expands dynamic context or edits
its files. It treats target instructions as data. It does not enforce a sandbox:
pre-existing Claude hooks/tools and permissions still operate in the host.

Entire accessible text source is required; unsupported encodings, huge files,
secret-bearing files, binary dependencies and external services are disclosed.
Incomplete source means an explicitly incomplete manual, not fabricated coverage.
Source inspection cannot prove actual LLM behavior, production reliability or
security. Runtime behavior is checked against current official docs where possible;
otherwise it is labeled unverified. No Claude runtime execution test was performed
when building this package; see `VALIDATION.md` for the exact checks performed.

## Package map

| Path | Purpose |
|---|---|
| SKILL.md | Agent workflow and operating contract |
| references/ | Audit, interaction, use-case and quality checklists |
| assets/manual-template.md | Output structure |
| scripts/source_audit.py | Optional inventory/read/coverage helper |
| tests/test_source_audit.py | Deterministic helper tests |
| tests/behavioral-cases.md | Behavioral acceptance plan, not claimed executed |
| agents/openai.yaml | Compatibility UI metadata, not used for Claude routing |

## Run the helper's unit tests

```text
python -m unittest discover -s tests -p "test_*.py" -v
```

The tests use temporary local fixtures and do not need Claude, network access,
third-party packages or actual installed skills. A pass does not establish that
Claude follows every instruction or that generated manuals are complete.

# Usage Guide Writer - Hướng dẫn cài đặt và sử dụng

Phiên bản: 1.0.0. Dành cho Claude Code.

Skill này đọc source của một skill khác và tạo tài liệu hướng dẫn
sử dụng chi tiết bằng Markdown. Ngôn ngữ đầu ra mặc định là tiếng Việt.
Instructions của gói được viết bằng tiếng Anh; bạn vẫn trao đổi bằng tiếng Việt.

## 1. Cài đặt trên Windows

Giải nén `skill.zip`, sau đó chép nguyên thư mục `usage-guide-writer`
vào **một** trong hai vị trí:

- Dùng cho nhiều project: `%USERPROFILE%/.claude/skills/usage-guide-writer/`
- Chỉ cho một project: `<project>/.claude/skills/usage-guide-writer/`

File phải nằm đúng tại `.../usage-guide-writer/SKILL.md`.
Không lồng thêm một thư mục `usage-guide-writer` nữa bên trong.
Mở một Local Session mới trong Claude Code và nhập `/usage-guide-writer`.
Đây là skill độc lập, không phải plugin marketplace.

Tài liệu Runtime: https://code.claude.com/docs/en/skills

## 2. Tạo hướng dẫn cho skill đã cài

Gửi prompt trong ô chat của Claude Code, không phải PowerShell:

```text
/usage-guide-writer
Hãy tạo hướng dẫn sử dụng chi tiết cho skill-creator tôi đã cài.
Trước tiên, xác định đúng bản cài và thư mục source.
Đọc toàn bộ source và tạo document Markdown tiếng Việt.
Chú trọng cách tiếp tục hội thoại, invoke lại, thay đổi dataset/rubric
và chạy lại test. Không invoke skill-creator hay chạy code của nó.
```

Khi có nhiều bản cài cùng tên, Agent phải phân biệt chúng trước khi viết.
Đường dẫn chính xác là đầu vào rõ nhất:

```text
/usage-guide-writer
Skill cần phân tích: C:/work/demo/.claude/skills/review-typescript
File đầu ra: C:/work/demo/docs/review-typescript-USAGE.md
Hãy tạo hướng dẫn đầy đủ, kèm use case và ví dụ cụ thể.
```

Thay các đường dẫn minh họa bằng đường dẫn thật.
Các dòng trong prompt là yêu cầu ngôn ngữ tự nhiên, không phải cú pháp flags.

## 3. Tiếp tục qua nhiều turn

Trong cùng cuộc hội thoại, có thể trả lời bình thường để bổ sung dữ liệu.
Không cần invoke lại chỉ vì sang turn mới. Ví dụ:

```text
Tiếp tục tài liệu đang viết. Bổ sung một use case về thay dataset
sau lần test đầu. Phân biệt chức năng có sẵn với cách làm bạn đề xuất.
```

Invoke lại **không tự động có nghĩa là reset**. Skill được hướng dẫn
đọc checkpoint, đối chiếu source và tiếp tục phần chưa hoàn thành.
Đây là instructions, không phải bảo đảm của một Workflow Engine.

Sang session mới, hãy cung cấp vị trí source và thư mục tài liệu/audit đã lưu.
Không giả định Agent còn nhớ cuộc hội thoại cũ.
Khi source thay đổi, yêu cầu đọc lại phần bị ảnh hưởng và cập nhật tài liệu.

## 4. Kết quả nhận được

Mặc định: `docs/skill-guides/<target-id>/USAGE.md`.
Các file trong `_audit/` ghi lại danh sách source, phạm vi đã đọc và tiến độ.
Đầu ra phải nằm ngoài thư mục source đang được phân tích.

Tài liệu bao gồm: chức năng, input/output, cách invoke, quy tắc multi-turn,
state, use case với ví dụ, xử lý lỗi, tác dụng phụ, giới hạn và dẫn chứng source.
Nếu có source quan trọng chưa đọc được, tài liệu phải ghi rõ là chưa hoàn chỉnh.

## 5. Giới hạn cần biết

Phân tích source không chứng minh hành vi LLM ngoài thực tế.
Skill không chạy target, benchmark hoặc cài dependency của target.
Nó cũng không tự tạo sandbox hay vô hiệu hóa hook đã có trong môi trường.

Python 3.10+ chỉ cần khi dùng helper kiểm kê đi kèm; nếu không có,
Agent có thể dùng file tools để thực hiện cùng quy trình.
Helper kiểm tra hash và khoảng dòng được khai báo, không chứng minh Agent
đã hiểu đúng hay tài liệu không bỏ sót hành vi.

Xem `VALIDATION.md` để biết phần đã kiểm thử và phần chưa kiểm thử.

#!/usr/bin/env python3
"""Materialize synthetic source fixtures and separate grading data. No model calls.

Does not install/enable targets, execute their code, or grade a manual. Creates a
new outside-package workspace and a NOT_RUN receipt; refuses existing destinations.
Python 3.10+, standard library only.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import sys
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone

ROOT=Path(__file__).resolve().parents[1]

def safe_relative(value: str) -> PurePosixPath:
    p=PurePosixPath(value)
    if not value or p.is_absolute() or '..' in p.parts or '\\' in value or ':' in value:
        raise ValueError(f'Unsafe fixture path: {value}')
    return p

def prepare(case_id: str, destination: Path) -> dict:
    suite=json.loads((ROOT/'evals/cases.json').read_text(encoding='utf-8'))
    case=next((x for x in suite['cases'] if x['id']==case_id),None)
    if case is None: raise ValueError('Unknown case ID; consult evals/README.md.')
    if destination.is_symlink() or destination.exists(): raise ValueError('Destination already exists; use a new run directory.')
    destination=destination.expanduser().resolve()
    if destination==ROOT or ROOT in destination.parents:
        raise ValueError('Use a workspace outside this writer package.')
    sources=case['files']
    for rel,value in sources.items():
        safe_relative(rel)
        if not isinstance(value,str): raise ValueError('Fixture contents must be text.')
    destination.mkdir(parents=True,exist_ok=False)
    target=destination/'input'/'target'
    target.mkdir(parents=True)
    hashes={}
    for rel,value in sources.items():
        p=target/safe_relative(rel)
        p.parent.mkdir(parents=True,exist_ok=True);p.write_text(value,encoding='utf-8',newline='\n')
        hashes[rel]=hashlib.sha256(value.encode('utf-8')).hexdigest()
    grading=destination/'grading';grading.mkdir()
    expected={k:v for k,v in case.items() if k!='files'}
    (grading/'expected.json').write_text(json.dumps(expected,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    scorecard={'case_id':case_id,'status':'NOT_RUN','reviewer':None,'manual_path':None,
        'trace_path':None,'assertions':[{'id':f'A{i:02d}','criterion':s,'result':'NOT_RUN','manual_evidence':None,'source_evidence':None}
         for i,s in enumerate(case['assertions'],1)],'critical_failure':None,'notes':'No semantic grading has been performed.'}
    (grading/'scorecard.json').write_text(json.dumps(scorecard,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    receipt={'case_id':case_id,'writer':suite['writer'],'writer_version':'3.0.0','target_kind':suite['target_kind'],
        'created_utc':datetime.now(timezone.utc).isoformat(),'status':'NOT_RUN',
        'runtime_version':None,'model':None,'source_sha256':hashes,
        'note':'Fixture files generated only. No writer or target was executed.'}
    (destination/'run-record.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    audit_target=target/'skills'/'evaluate' if suite['writer']=='skill-document' and case_id=='T05' else target
    request=(f"/{suite['writer']}\nCreate a detailed Vietnamese usage manual for this {suite['target_kind']}: {audit_target.as_posix()}\n"
       f"Output: {(destination/'output'/'USAGE.md').as_posix()}\n"
       "Use static source inspection only. Do not invoke/install/run the target.\n"
       "Read only the input target and required writer references, not grading data or eval answer keys.\n")
    (destination/'REQUEST.md').write_text(request,encoding='utf-8')
    return {'workspace':str(destination),'target':str(target),'request':str(destination/'REQUEST.md'),'status':'NOT_RUN'}

def main() -> int:
    if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf-8')
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--case',required=True);p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    try:
        print(json.dumps(prepare(a.case,a.out),ensure_ascii=False,indent=2));return 0
    except (OSError,ValueError,KeyError,TypeError) as e:
        print(json.dumps({'error':str(e)}));return 1
if __name__=='__main__':raise SystemExit(main())

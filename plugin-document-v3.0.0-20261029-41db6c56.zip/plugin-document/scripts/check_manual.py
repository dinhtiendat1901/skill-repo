#!/usr/bin/env python3
"""Check a documentation operation contract against a Markdown manual.

Python 3.10+, standard library. Does NOT execute target source, call an LLM,
verify truth of citations, discover omitted target features or grade semantics.
Exit 0 = structural consistency only; 2 = validation errors; 1 = input/IO error.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any

SCENARIOS = (
    'first_use', 'answer_clarification', 'supply_input', 'feedback',
    'repeat_invocation', 'change_arguments', 'change_dataset_rubric',
    'new_task', 'interruption', 'compaction', 'new_session', 'source_update',
    'delegation', 'partial_failure', 'completion', 'cancellation',
)
PLUGIN_SCENARIOS = ('switch_component', 'automatic_event', 'plugin_lifecycle')
RUNTIME_ASPECTS = ('arguments', 'preprocessing', 'permissions', 'hooks', 'context', 'state_restore')
INTERACTIONS = {'invoke', 'follow_up', 'new_session', 'other_entrypoint', 'ui', 'shell', 'event', 'stop'}
INTERFACES = {'formal', 'free_text', 'ui', 'shell', 'event', 'none'}
POLICIES = {'required', 'recommended', 'optional', 'not_applicable', 'unknown'}
LEVELS = {'SOURCE-INSTRUCTION', 'SOURCE-CODE', 'RUNTIME-DOC', 'INFERENCE', 'RECOMMENDATION', 'UNKNOWN'}
OP_TEXT = ('component', 'goal', 'preconditions', 'action', 'policy_reason',
           'parameter_note', 'state_after', 'result_policy', 'next_actor',
           'completion_signal', 'failure_action', 'limitations')
PARAM_TEXT = ('name', 'form', 'requirement', 'binding', 'resend_rule', 'example',
              'missing_behavior', 'effective_when', 'state_effect')
EVIDENCE = re.compile(r'\[(SOURCE-INSTRUCTION|SOURCE-CODE|RUNTIME-DOC|INFERENCE|RECOMMENDATION|UNKNOWN);\s*([^\]]+)\]')
BLOCK = re.compile(r'<!--\s*(OP[0-9]{2,}):BEGIN\s*-->(.*?)<!--\s*\1:END\s*-->', re.S)


def text(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def norm(value: str) -> str:
    return ' '.join(value.split())


def validate(data: Any, manual: str) -> dict[str, Any]:
    errors: list[str] = []
    warnings: list[str] = []
    def err(where: str, message: str) -> None:
        errors.append(f'{where}: {message}')
    def strings(obj: dict[str, Any], keys: tuple[str, ...], where: str) -> None:
        for key in keys:
            if not text(obj.get(key)):
                err(where, f'{key} must be non-empty text (use an explained unknown when needed)')
    def evidence(value: Any, where: str) -> None:
        if not isinstance(value, list) or not value:
            err(where, 'evidence must be a non-empty list')
            return
        for entry in value:
            if not text(entry) or not EVIDENCE.fullmatch(entry):
                err(where, 'use [LABEL; source/path:Lx-Ly], runtime URL/date, or an explained UNKNOWN')
                continue
            label, locator = EVIDENCE.fullmatch(entry).groups()
            if label in {'SOURCE-INSTRUCTION', 'SOURCE-CODE'} and not re.search(r':L[1-9][0-9]*-L[1-9][0-9]*',locator):
                err(where, 'source evidence needs a line range')
            if label == 'RUNTIME-DOC' and ('https://' not in locator or not re.search(r'\d{4}-\d{2}-\d{2}',locator)):
                err(where, 'runtime evidence needs an official HTTPS URL and check date')
    def contained(value: Any, block: str, where: str) -> None:
        if text(value) and norm(value) not in norm(block):
            err(where, 'value is absent from the matching manual operation card')

    if not isinstance(data, dict):
        return {'structural_ok': False, 'errors': ['root must be an object'],
                'warnings': [], 'semantic_evaluation': 'NOT_PERFORMED'}
    if type(data.get('schema_version')) is not int or data['schema_version'] != 1:
        err('root', 'schema_version must be 1')
    target = data.get('target', {})
    if not isinstance(target, dict):
        err('target', 'must be an object')
        target = {}
    strings(target, ('id','snapshot','runtime'), 'target')
    if target.get('kind') not in {'skill', 'plugin'}:
        err('target', 'kind must be skill or plugin')
    if data.get('coverage_status') not in {'complete_within_scope','incomplete'}:
        err('root', 'coverage_status must be complete_within_scope or incomplete')
    gaps=data.get('gaps')
    if not isinstance(gaps,list) or any(not text(x) for x in gaps):
        err('root','gaps must be a list of non-empty descriptions')
    elif gaps and data.get('coverage_status')!='incomplete':
        err('root','material gaps require coverage_status=incomplete')
    elif data.get('coverage_status')=='incomplete' and not gaps:
        err('root','incomplete requires at least one gap')
    if data.get('coverage_status')=='incomplete':
        if 'INCOMPLETE' not in manual:
            err('manual','show INCOMPLETE prominently for material gaps')
        warnings.append('Manual has disclosed material gaps; a structural pass is not completeness.')
    operations=data.get('operations')
    if not isinstance(operations,list) or not operations:
        err('operations','must contain at least one operation (a stop/diagnosis card is valid)')
        operations=[]
    blocks: dict[str,str]={}
    for oid,body in BLOCK.findall(manual):
        if oid in blocks: err('manual',f'duplicate card {oid}')
        blocks[oid]=body
    seen: set[str]=set()
    for i,op in enumerate(operations):
        where=f'operations[{i}]'
        if not isinstance(op,dict):
            err(where,'must be an object'); continue
        oid=op.get('id')
        if not isinstance(oid,str) or not re.fullmatch(r'OP[0-9]{2,}',oid):
            err(where,'id must look like OP01'); continue
        if oid in seen: err(where,'duplicate operation ID')
        seen.add(oid)
        strings(op,OP_TEXT,oid)
        for field,choices in [('interaction',INTERACTIONS),('interface',INTERFACES),('invocation_policy',POLICIES),('evidence_level',LEVELS)]:
            if op.get(field) not in choices: err(oid,f'invalid {field}')
        if op.get('evidence_level')=='UNKNOWN':
            warnings.append(f'{oid}: unknown behavior requires reader attention.')
        if op.get('interaction')=='follow_up' and str(op.get('action','')).lstrip().startswith('/'):
            err(oid,'ordinary follow-up example must not start with a slash invocation')
        if op.get('interface')=='event' and op.get('interaction')!='event':
            err(oid,'automatic interface must use interaction=event')
        if op.get('interface')=='none' and op.get('interaction')!='stop':
            err(oid,'no interface requires a stop/diagnosis operation')
        evidence(op.get('evidence'),oid)
        params=op.get('parameters')
        if not isinstance(params,list): err(oid,'parameters must be a list'); params=[]
        param_names:set[str]=set()
        block=blocks.get(oid)
        if block is None: err(oid,'missing <!-- OPxx:BEGIN -->...<!-- OPxx:END --> manual card')
        for j,p in enumerate(params):
            pw=f'{oid}.parameters[{j}]'
            if not isinstance(p,dict): err(pw,'must be an object'); continue
            strings(p,PARAM_TEXT,pw)
            if p.get('resend') not in {'yes','no','conditional','unknown','not_applicable'}:
                err(pw,'resend must be yes/no/conditional/unknown/not_applicable')
            name=p.get('name')
            if isinstance(name,str):
                if name in param_names: err(pw,'duplicate parameter name')
                param_names.add(name)
            evidence(p.get('evidence'),pw)
            if block is not None:
                for k in PARAM_TEXT:
                    contained(p.get(k),block,f'{pw}.{k}')
        runtime=op.get('runtime_comparison')
        if not isinstance(runtime,dict): err(oid,'runtime_comparison must be an object'); runtime={}
        for aspect in RUNTIME_ASPECTS:
            r=runtime.get(aspect)
            rw=f'{oid}.runtime_comparison.{aspect}'
            if not isinstance(r,dict): err(rw,'missing comparison'); continue
            if r.get('status') not in {'different','equivalent','not_applicable','unknown'}:
                err(rw,'invalid status')
            strings(r,('details',),rw)
            evidence(r.get('evidence'),rw)
            if block is not None:
                contained(r.get('details'),block,rw+'.details')
        if block is not None:
            for k in OP_TEXT:
                contained(op.get(k),block,f'{oid}.{k}')
            for e in op.get('evidence',[]) if isinstance(op.get('evidence'),list) else []:
                contained(e,block,f'{oid}.evidence')
    for extra in blocks.keys()-seen:
        err('manual',f'card {extra} not listed in operations')
    scenarios=data.get('scenarios')
    if not isinstance(scenarios,list): err('scenarios','must be a list'); scenarios=[]
    required=set(SCENARIOS + (PLUGIN_SCENARIOS if target.get('kind')=='plugin' else ()))
    scenario_seen:set[str]=set()
    used:set[str]=set()
    for idx,row in enumerate(scenarios):
        sw=f'scenarios[{idx}]'
        if not isinstance(row,dict): err(sw,'must be an object'); continue
        sid=row.get('id')
        if not isinstance(sid,str): err(sw,'id must be text'); continue
        if sid in scenario_seen: err(sw,'duplicate scenario')
        scenario_seen.add(sid)
        if row.get('status') not in {'covered','not_applicable','unsupported','unknown'}:
            err(sw,'invalid status')
        strings(row,('reason',),sw)
        refs=row.get('operation_ids')
        if not isinstance(refs,list) or any(not isinstance(x,str) for x in refs):
            err(sw,'operation_ids must be a string list'); refs=[]
        if row.get('status')=='covered' and not refs:
            err(sw,'covered scenario must reference operations')
        for ref in refs:
            if ref not in seen: err(sw,f'unknown operation {ref}')
            else: used.add(ref)
    for sid in sorted(required-scenario_seen): err('scenarios',f'missing {sid}')
    for oid in sorted(seen-used): err('operations',f'{oid} has no scenario mapping')
    if not manual.strip(): err('manual','empty')
    if '{{' in manual or '}}' in manual: warnings.append('Possible unresolved template markers; inspect manually.')
    return {
        'schema_version':1, 'structural_ok':not errors,
        'operation_count':len(seen), 'scenario_count':len(scenario_seen),
        'coverage_status':data.get('coverage_status'),
        'errors':errors, 'warnings':warnings, 'semantic_evaluation':'NOT_PERFORMED',
        'limitation':'Checks required fields and selected manual/JSON agreement only. Does not verify source truth, missing features, runtime behavior or overall quality.',
    }


def read_file(path: Path) -> str:
    if path.is_symlink() or not path.is_file():
        raise ValueError(f'Expected a regular non-symlink input file: {path}')
    if path.stat().st_size>32*1024*1024:
        raise ValueError('Input exceeds 32 MiB; review/split it explicitly.')
    return path.read_text(encoding='utf-8-sig')


def main() -> int:
    if hasattr(sys.stdout,'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--operations',type=Path,required=True)
    parser.add_argument('--manual',type=Path,required=True)
    parser.add_argument('--out',type=Path)
    args=parser.parse_args()
    try:
        raw=read_file(args.operations); manual=read_file(args.manual)
        result=validate(json.loads(raw),manual)
        result['input_sha256']={'operations':hashlib.sha256(raw.encode('utf-8')).hexdigest(),
                                'manual':hashlib.sha256(manual.encode('utf-8')).hexdigest()}
        output=json.dumps(result,ensure_ascii=False,indent=2)+'\n'
        if args.out:
            if args.out.is_symlink() or args.out.exists():
                raise ValueError('Report exists or is a symlink; choose a new report path (no silent overwrite).')
            if args.out.resolve() in {args.operations.resolve(),args.manual.resolve()}:
                raise ValueError('Output cannot replace an input.')
            args.out.parent.mkdir(parents=True,exist_ok=True)
            with args.out.open('x',encoding='utf-8',newline='\n') as f: f.write(output)
        print(output,end='')
        return 0 if result['structural_ok'] else 2
    except (OSError,ValueError,TypeError,KeyError) as exc:
        print(json.dumps({'error':str(exc),'semantic_evaluation':'NOT_PERFORMED'},ensure_ascii=False))
        return 1

if __name__=='__main__':
    raise SystemExit(main())

# Plugin invocation, lifecycle and interaction contract

## Contents
1. Public interfaces
2. Decision matrix
3. State ownership
4. Operational details
5. Evidence-aware recommendations

## 1. Public interfaces

Answer what the USER types or does, where they do it, who acts next, and what
state must already exist. Analyze each component plus cross-component effects;
do not write one generic conversation protocol for the entire plugin.

Inspect every frontmatter/registration field, including unfamiliar ones. Verify
naming, visibility, invocation policy, argument hints/substitution, dynamic context,
context fork/delegation, model, tools, hooks, dependencies and permissions.
A UI hint is not a parser; instructions to validate input are not code validation.

Classify each interface as:
- A user-invocable command/skill in Claude chat, with verified namespace.
- A natural-language request routed by the Agent, not a guaranteed formal API.
- A delegated agent or internal helper, not necessarily directly user-invocable.
- A shell CLI explicitly exposed by the author, distinct from internal scripts.
- A UI/settings operation specific to the user's surface/version.
- An automatic runtime event, hook, monitor or server lifecycle, with no user command.

Check `references/runtime-sources.md` for runtime semantics. Record version/date
and separate installed configuration from assumptions. Do not invent exact token
budgets, retention/permission lifetimes, reload behavior or hidden slash commands.

## 2. Required decision matrix

For each row give: component/feature, situation, exact user action, interaction
mode, prerequisite state, next actor, effects, evidence level and limitation.
Group identical rules by component only when source supports that equivalence.
Mark unsupported/not applicable/unknown explicitly; do not omit awkward cases.

| Situation | What must be resolved |
|---|---|
| Before first use | Required install/enable/config/auth steps, tools and access; any automatic effects before invoking? |
| First explicit task | Which actual child entrypoint? Required args? What happens before the model responds? |
| Implicit use | When might the Agent choose a child skill, agent or tool without a direct command? |
| Answering a clarification | Ordinary reply or another entrypoint? Which Agent/context is waiting? |
| Supplying more files | Paths, attachments or config? Continue, replace input or begin another task? |
| Supplying project/dataset/rubric | Which component reads them, schema, snapshot, defaults and unsupported fields? |
| Requesting execution after setup | Required state, checks and approval; code enforcement or merely instructions? |
| Feedback on output | Revise result, improve skill, rerun eval or only store feedback? |
| Repeating the same entrypoint | New execution, reuse, overwrite, duplicate external effect or unknown? |
| Changing arguments/config | When does the value apply? Does it invalidate existing results? |
| Switching child components | Is state shared, passed explicitly, re-read from disk or lost? |
| Starting another project/task | Shared paths, caches, workspace identity and collision risks? |
| Parent/child or forked context | Who holds state? How can the user provide feedback and receive results? |
| User interrupts or changes subject | Cancellation, pending effects and supported continuation? |
| Long session or compaction | Which files/state are recoverable, and what must be provided again? |
| Fresh session or machine | Source/config credentials/artifacts required; no presumed restored workflow |
| Plugin install/enable/reload/update | What becomes visible or starts automatically, and version-dependent steps? |
| Disable/uninstall | What stops, what may persist, credentials/data/remote artifacts and cleanup limits? |
| Automatic hook/event | Trigger, matcher, handler, context/tool affected; what should the user observe? |
| Server/monitor restart or timeout | Startup, reconnect, duplicates, health and state loss where specified |
| Denial/auth failure/missing dependency | Safe action; whether retry is supported and whether earlier work persists |
| Partial failure or rerun | Which outputs are complete, rollback/idempotence and safe retry boundaries? |
| Completed workflow | Does it stop, leave a process running, accept follow-up or require new invocation? |

Reinvocation is not inherently reset, resume, reconfiguration or repair. Keeping
instructions in context is not a guarantee of applicability, authority or correct
state. Not invoking a skill does not disable the plugin's automatic components.

## 3. State ownership

For each input/config/artifact, record: owner component, storage (conversation,
child context, file, process, runtime config or remote service), who updates it,
version/run identity, lifetime, invalidation, consumers, collision/overwrite risk
and documented recovery. Separate plugin installation/cache from working project
and output directories. If state storage is absent, say conversation-only/unknown.

Trace handoffs explicitly. If one component writes `feedback.json` and another
reads it, verify the path/schema agreement. If the source merely says "remember",
"wait", "approve" or "continue", label this an author instruction, not a persistent
transaction/state machine. Do not infer sharing from identical variable names.

For custom scoring, determine whether the rubric is read by a grader prompt, a
parser or a deterministic scoring script. A benchmark aggregator may not support
arbitrary penalties, weights or metrics. Changing a rubric can invalidate prior
comparisons; label versioning advice as RECOMMENDATION unless implemented.

## 4. Small operational details that must not be lost

Inspect working directory versus install/root/data directories; relative path
resolution; environment placeholders versus shell expansion; Windows quoting and
spaces; interpreter and external binary requirements; line endings where relevant;
API/network/authentication and permission prompts; defaults and missing inputs;
output append/overwrite/cleanup; rerun/iteration IDs; model settings and baseline
isolation; event matchers; synchronous/asynchronous/blocking decisions; returned
exit codes; timeouts and retries; processes left running; configuration precedence;
version changes and availability differences between Desktop, CLI, IDE and cloud.
Only explain actual source-backed behavior; do not make every item a feature.

A plugin may act before the requested child skill begins. Put such cautions before
quickstart steps rather than hiding them in a security appendix. Do not suggest
bypassing permissions, suppressing hooks or exposing credentials to simplify usage.

## 5. Evidence-aware recommendations

If an author specifies a wait for feedback and a subsequent file read, document
that continuation and the file. If fresh-session recovery is not defined, write:
"Not specified. Recommended fallback: provide the workspace, inspect saved outputs
and confirm the pending operation before rerunning." Do not invent `/plugin resume`.

Where source and implementation disagree, show both citations, the practical risk
and a safe proposed action. Keep the uncertain field visible instead of choosing
the convenient interpretation. Runtime facts require version-aware evidence.

## Version 3 operation-level completion gate

Apply references/operation-contract.md (relative to the writer root). A relevant
scenario must link to an OP card with complete typed action, parameter binding and
resend rules, prior/post-state, result invalidation, retry effects and evidence.
Inputs in a remote chapter do not substitute for per-action parameter instructions.
Check that follow-up vs explicit invocation is compared where runtime effects may
differ. Re-read sources for these claims; unknowns must not be silently resolved.
Render OP markers in USAGE.md; save operations.json and REVIEW.md in _audit/.
The structural check and semantic self-review are distinct gates. Report their
actual status, never convert a helper pass into an end-to-end quality claim.

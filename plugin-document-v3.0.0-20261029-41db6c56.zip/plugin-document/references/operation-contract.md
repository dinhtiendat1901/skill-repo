# Operation, parameter and state contract

## Contents
1. Goal and scope
2. Build the operation inventory
3. Required operation card
4. Compare continuation with invocation
5. Structured sidecar and consistency check
6. Unknown behavior and semantic review

## 1. Goal and scope

Make every consequential user action executable without assembling its meaning
from disconnected chapters. Document what to type, in which surface, when, with
which inputs, and what changes afterward. The writer's own continuation rules do
NOT define the target's continuation rules. A target may restart on every invoke,
continue from files, or have no documented recovery; inspect it independently.

This contract describes a target. It is not a new API imposed on the target.
Do not fabricate resume/reset verbs, command flags, typed parameters or retained
configuration. A free-text prompt is an example, not a parser grammar. Explain
which parts are literal keywords and which are example paths/values to replace.

## 2. Build the operation inventory

Assign OP01, OP02, etc. to user actions and consequential automatic events. Cover
first invocation, ordinary answers, added inputs, feedback, repeated invocation,
changed parameters/dataset/rubric, new tasks, interruption, compact/new session,
source updates, delegation, failure/retry, completion and cancellation. For a
plugin, also cover component switching, automatic events and installation
lifecycle. Mark irrelevant cases N/A with a reason; unsupported and unknown are
NOT synonyms for N/A. Use the scenario IDs in the example JSON/schema reference.

Map component/feature -> scenario -> operation -> use case -> evidence. Split
operations when their input binding, entrypoint, state ownership or side effects
differ. Group only genuinely equivalent actions; never use a generic 'continue'
row for all modes. A recovery recommendation must remain distinct from a native
resume operation. A missing source can require a stop/diagnosis operation.

## 3. Required operation card

Use `assets/operation-card-template.md`. Each card must have:

- Goal, component/mode, situation, source version and prerequisite state.
- Interaction: explicit invoke, ordinary follow-up, fresh-session setup, different
  entrypoint, UI, shell, automatic event or stop. State the actual surface.
- Invocation policy: required/recommended/optional/not applicable/unknown, with
  why and evidence. Required by author instruction is not code enforcement.
- A complete, copyable action. No unexplained 'repeat previous args'. For a formal
  interface show its verified grammar plus a filled example; for a free-text
  interface label the wording as illustrative. Automatic events need a trigger
  timeline, NOT an invented slash command.
- For EACH input/option, including project/dataset/rubric/run/workspace as relevant:
  name and position/syntax, requirement/default, where its value comes from,
  whether to send it again, what happens if omitted, when a replacement takes
  effect, which prior results become stale, and a safe example plus evidence.
- State after the action, result reuse/invalidation, output path resolution,
  append/overwrite/new-run effects, next actor, waiting/approval and observable
  completion. Explain failure and safe retry; do not claim idempotence from name.
- A follow-up vs invoke comparison for the relevant runtime effects, evidence and
  explicit unknowns. Do not claim actual execution based on source reading.

Put these facts TOGETHER in each card. A general parameter catalog is not a
substitute. If there are no parameters, say so with a reason. An unknown binding
must remain unknown; provide a conservative labeled recommendation separately.

## 4. Compare continuation with invocation

For each operation classify these six dimensions as different/equivalent/N/A/
unknown and explain WHY with source or current official runtime evidence:

| Dimension | Questions to resolve |
|---|---|
| arguments | Are values substituted on invocation, read from current conversation, or parsed by code? Which must be sent again? |
| preprocessing | Is a command/snapshot refreshed on invocation? What can run before the model validates inputs? |
| permissions | Does invocation change a temporary grant/restriction/model override? What baseline permissions remain? |
| hooks | Does direct slash expansion differ from model-driven Skill tool use? Are applicable hooks actually configured/loaded? |
| context | Main conversation, newly forked agent, or independent process? Who receives the user's next message? |
| state_restore | Which files/run IDs are re-read? Does a file merely persist or is loading actually defined? |

Check local version and surface (Desktop/IDE/CLI/cloud). Official docs are lookup
sources, not proof that the installed runtime supports every feature. In an offline
audit preserve local facts and mark runtime-dependent conclusions unverified. Do
not advise reinvocation solely to acquire permissions; normal approval may suffice.
Do not state 'no slash command means no hook': ordinary messages may trigger other
host events. Do not assume loading instructions restarts or restores a workflow.

## 5. Structured sidecar and consistency check

Write `_audit/operations.json`, schema version 1, following
`assets/operations-example.json` and `references/operations-format.md`. This is a
WRITER artifact, not a target configuration. Render the same facts in USAGE.md;
never force a reader to open JSON to discover a required parameter.

Surround each card with `<!-- OP01:BEGIN -->` and `<!-- OP01:END -->` (unique IDs).
Keep every operation/parameter text field and runtime-comparison detail
consistent between JSON and the corresponding card, including the action, binding,
resend rule, missing behavior, effective time, states and main evidence. This permits a bounded
structural check without pretending to understand prose. All substantive claims
still need their own labeled evidence, not just one citation for an entire page.

If Python is available, run the trusted writer helper, never a target helper:

```text
python <writer-root>/scripts/check_manual.py --operations <output>/_audit/operations.json --manual <output>/USAGE.md --out <output>/_audit/manual-check.json
```

Use a new report filename on rerun; this helper refuses overwrites. Record the
actual latest report path in ANALYSIS.md. Exit 0 means structural consistency,
not semantic accuracy. An explicitly incomplete guide can pass structurally.
If Python is unavailable, perform the same checklist manually and write
`manual-check.md` labeled MANUAL_CHECK_ONLY; do not fabricate a JSON script result.

## 6. Unknown behavior and semantic review

Read `references/manual-review.md` after drafting. Inspect the actual manual,
not only the sidecar. A fully filled JSON can still be wrong. Re-read evidence for
every high-risk transition: resending inputs, dataset change, replay, forked
handoff and recovery. Log review findings in `_audit/REVIEW.md` using its template.
Clearly distinguish self-review from independent review and from runtime testing.
If a source gap prevents correct operating instructions, label the manual
INCOMPLETE and identify the blocked operations. Do not turn UNKNOWN into supported
behavior to achieve a clean report. Keep all noncritical uncertainties visible.

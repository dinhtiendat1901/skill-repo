# Runtime verification starting points

Authoring lookup date: 2026-10-27. These links are navigation aids, NOT a frozen
specification or proof of support in the user's installed version. Re-check the
needed official sections and the known runtime version when writing a manual.
If offline or unsupported by available tools, explicitly mark runtime claims
unverified. Do not copy speculative context/token/permission lifetime numbers.

| Topic | Official starting point |
|---|---|
| Plugin concept and surfaces | https://code.claude.com/docs/en/plugins/overview |
| Component types and naming | https://code.claude.com/docs/en/plugins/components |
| Manifest, custom/inline paths and configuration | https://code.claude.com/docs/en/plugins/manifest-reference |
| Install scope and management | https://code.claude.com/docs/en/plugins/install |
| Loading/configuration precedence | https://code.claude.com/docs/en/plugins/loading-reference |
| Security and automatic execution | https://code.claude.com/docs/en/plugins/security |
| Skills, frontmatter and content lifecycle | https://code.claude.com/docs/en/skills |
| Subagents and context | https://code.claude.com/docs/en/sub-agents |
| Hook events and handlers | https://code.claude.com/docs/en/hooks |
| MCP integration | https://code.claude.com/docs/en/mcp |
| Permissions | https://code.claude.com/docs/en/permissions |
| Documentation index if a path moved | https://code.claude.com/docs/llms.txt |

The authoring check directly opened the overview/components/manifest/install/
security/skills pages. Other links are lookup starting points, not claims that
all their contents have been verified during this package build.

Do not assume a universal rule that custom paths always extend defaults. Resolve
per-field behavior and version. Do not assume install, enable, reload, new turn,
new session and child-agent delegation have the same effects. Separate runtime
facts from plugin-specific intent and recommended operation.

Cite source paths for features; cite official docs for runtime mechanics. Do not
use third-party blog snippets as authoritative lifecycle contracts. Never send
private target source, configuration values or credentials in web requests.


# Runtime lookup guide

Official primary sources (checked 2026-10-29; re-check for the installed version):
- https://code.claude.com/docs/en/skills#skill-content-lifecycle
- https://code.claude.com/docs/en/skills#pass-arguments-to-skills
- https://code.claude.com/docs/en/skills#inject-dynamic-context
- https://code.claude.com/docs/en/skills#pre-approve-tools-for-a-skill
- https://code.claude.com/docs/en/skills#run-skills-in-a-subagent
- https://code.claude.com/docs/en/hooks#userpromptexpansion
- https://code.claude.com/docs/en/hooks#pretooluse
- https://code.claude.com/docs/en/plugins-reference
- https://code.claude.com/docs/en/permissions

Review implications, not universal policies: persisted instructions and temporary
tool approval differ; substitution/preprocessing takes place on invocation;
forked execution introduces a context boundary. Direct slash expansion and a
model's Skill tool call can encounter different configured hooks. The actual
installed version, configuration, permission policy and successful preprocessing
matter. A new invoke is not inherently reset, resume or permission bypass.

These links are evidence lookup starting points, not target feature declarations.
Do not freeze exact compaction budgets or infer flags from generic documentation.
If unavailable, label runtime claims UNKNOWN and preserve verified source facts.

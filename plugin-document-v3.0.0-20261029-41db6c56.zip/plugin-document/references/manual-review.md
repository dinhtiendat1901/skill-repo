# Review the generated manual, not only the source ledger

## Three distinct checks

1. Source coverage: inventories/read ledgers; validates declared ranges and hashes.
2. Structural consistency: `check_manual.py` reads operations.json AND USAGE.md;
   checks fields, coverage links and selected text agreement. Not a semantic grader.
3. Semantic review: read the guide against the audited source/runtime evidence.
   The authoring Agent can self-review, but must label it SELF_REVIEW, not independent.
   An independent reviewer needs its own source access and rubric; even another
   model is not automatically correct. Runtime testing is a fourth, separate task.

## Required review questions

For each OP card, ask these concrete questions and record answers/findings:
- Can a novice perform the next action using this card without reconstructing args
  from other chapters? Are example values and literal keywords distinguishable?
- Does the exact example use a real interface and the right namespace/surface?
- Are all required inputs present, correctly positioned and quoted? What if omitted?
- For every parameter, is resend/reuse/read-from-file explicit and source-backed?
- Is the selected run/workspace/config unambiguous? Does a dataset/rubric change
  invalidate previous results or require a new run? Is that fact or recommendation?
- Does the guide confuse a follow-up with a fresh invocation, rebind or restart?
- Are preprocessing, temporary tool policies, hooks and forked context treated
  separately? Is 'file exists' incorrectly turned into automatic restoration?
- Are retry/duplicate write/overwrite/cancellation risks stated before the action?
- Are automatic plugin effects and component handoffs described without invented
  commands or assumed shared conversation state?
- Can each material assertion be traced to actual lines? Are contradictory prose
  and code, missing source and unverified runtime behavior visible to the user?

## Fatal defects (do not silently ship as ready)

Unsupported command/flag, required input omitted in a copyable example, wrong
resend/reuse or run identity, false resume guarantee, concealed destructive effect,
unsupported hook/runtime guarantee, wrong installed target, fabricated citation,
false full-read claim, intentional target execution or secret disclosure.
Fix verified defects. If source cannot resolve an operationally significant gap,
mark INCOMPLETE and show the blocker; do not 'fix' the target by inventing behavior.

## Review record

Use `assets/review-template.md`. Record actual date, reviewer type, files and
snapshot, each checked OP, findings with guide AND source locations, corrections,
and remaining gaps. Never claim a review was independent or executed without
its artifacts. Mark unperformed checks NOT_RUN, not PASS. At handoff separately
report source coverage, structural result, self-review, independent semantic
review, and Claude Code execution status.

## Evaluating this writer (separate from documenting a target)

The fixtures in evals/cases.json have known intended contracts. Use
`evals/README.md` and its rubric. Do NOT read expected answers while producing a
candidate manual. Do not run tests during a normal documentation request. Fixture
controls and code unit tests do not establish quality of real Claude outputs.

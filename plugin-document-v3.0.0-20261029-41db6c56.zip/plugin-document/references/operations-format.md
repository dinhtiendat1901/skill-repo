# operations.json format (writer-owned, schema_version 1)

The complete filled example in `assets/operations-example.json` is illustrative,
not a claim about any installed target. Replace all fixture facts and source lines.
Use UTF-8 JSON with translated free-text values; keep keys/enums/IDs unchanged.

## Top-level fields

- `schema_version`: integer 1.
- `target`: object with nonempty `id`, `snapshot`, `runtime`; `kind`: skill/plugin.
  Snapshot must describe the actual audited version/hash, not the writer version.
- `coverage_status`: complete_within_scope/incomplete. This is SOURCE coverage,
  not an accuracy guarantee or a test result. `gaps`: array of material gap text;
  nonempty gaps require incomplete. Noncritical unknowns belong in card limitations.
- `scenarios`: list of `{id, status, reason, operation_ids}`. Status is covered,
  not_applicable, unsupported, unknown. Covered requires operation references.
  Provide a nonempty reason even for N/A. Every operation must be referenced.
- `operations`: nonempty list of operation objects. A diagnosis/stop card may
  explain why the only usable outcome is INCOMPLETE.

Required skill scenario IDs:
`first_use`, `answer_clarification`, `supply_input`, `feedback`, `repeat_invocation`,
`change_arguments`, `change_dataset_rubric`, `new_task`, `interruption`, `compaction`,
`new_session`, `source_update`, `delegation`, `partial_failure`, `completion`,
`cancellation`.
Additional plugin IDs: `switch_component`, `automatic_event`, `plugin_lifecycle`.
Additional target-specific IDs are allowed and need the same fields.

## Operation fields

| Key | Value |
|---|---|
| id | OP01, OP02, ... (unique; at least 2 digits) |
| component | Actual target skill/component; not necessarily a slash command |
| goal | Concrete user intent/situation |
| preconditions | State/files/permissions needed before the action |
| interaction | invoke/follow_up/new_session/other_entrypoint/ui/shell/event/stop |
| interface | formal/free_text/ui/shell/event/none |
| invocation_policy | required/recommended/optional/not_applicable/unknown |
| policy_reason | Why this route is needed or only recommended |
| action | Complete example text, UI action or event timeline; do not execute |
| parameters | Parameter objects (empty list allowed with parameter_note) |
| parameter_note | Explain how the parameters work or why none exist |
| state_after | What state should exist afterward; source-backed or explicit unknown |
| result_policy | Reuse, staleness, append/overwrite, new run and path risks |
| next_actor | User/parent/child/runtime plus waiting/approval explanation |
| completion_signal | Observable end state/expected artifacts; never fake a successful run |
| failure_action | Supported safe retry or labeled fallback |
| evidence_level | SOURCE-INSTRUCTION/SOURCE-CODE/RUNTIME-DOC/INFERENCE/RECOMMENDATION/UNKNOWN |
| evidence | Nonempty list of labeled evidence strings |
| limitations | Caveats; use 'None identified within the inspected scope' when justified |
| runtime_comparison | Object with all six dimensions described below |

Parameter object keys (all required): `name`, `form`, `requirement`, `binding`,
`resend`, `resend_rule`, `example`, `missing_behavior`, `effective_when`,
`state_effect`, `evidence`.
All are nonempty text except evidence (nonempty string list); resend is exactly
`yes`, `no`, `conditional`, `unknown`, or `not_applicable`.
Explain default vs retained value, absent vs empty, and path-base/quoting where
relevant. Requirement can be conditional natural language; it is not a typed API.
For unknowns use an explained UNKNOWN evidence entry, not invented line numbers.

`runtime_comparison` has keys `arguments`, `preprocessing`, `permissions`, `hooks`,
`context`, `state_restore`. Each is `{status, details, evidence}` with status
`different`, `equivalent`, `not_applicable`, `unknown`; details is nonempty text;
evidence is a nonempty list. N/A needs a reason and scope; unknown needs a blocker.

Evidence string examples:
`[SOURCE-INSTRUCTION; TARGET/SKILL.md:L4-L9]`
`[SOURCE-CODE; TARGET/scripts/review.py:L12-L25]`
`[RUNTIME-DOC; https://code.claude.com/docs/en/skills; checked 2026-10-29; installed version unknown]`
`[UNKNOWN; No recovery contract found in the inspected sources]`
`[RECOMMENDATION; Conservative fallback based on TARGET/SKILL.md:L4-L9]`

## Checker limits

The script checks mandatory fields, enum values, scenario/operation links, card
markers and operation/parameter text agreement (whitespace-normalized). It checks
citation SHAPE, not whether cited paths/lines exist or support a claim. It cannot
identify a fabricated operation that is internally consistent, omitted capabilities,
false N/A, incorrect state inference, secret leakage or incorrect runtime facts.
A human or independently checked semantic grader must perform those checks.
Do not optimize prose just to pass a checker. No source is executed by this script.

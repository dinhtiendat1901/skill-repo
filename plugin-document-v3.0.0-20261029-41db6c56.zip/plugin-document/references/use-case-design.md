# Plugin use-case design

## Derive scenarios from components, capabilities and branches

Create component IDs C01, C02, feature IDs F01, F02 and use cases UC01, UC02.
Cover each supported public feature, consequential decision/configuration branch,
automatic behavior and cross-component handoff. Include dormant components in the
inventory without presenting them as available user features. For unknown behavior,
write a limitation, not an invented successful case.

Use a happy path for each distinct capability. Add separate cases when state,
inputs, permissions, dependencies, lifecycle, error recovery or side effects alter
what the user must do. Combine minor variants in a clear table. Do not manufacture
hundreds of equivalent prompts or claim all possible conversations are enumerated.

Inspect applicable cases: first configuration; each public entrypoint; ordinary
follow-up; passing project/dataset/rubric; changing inputs; viewing output; feedback;
repeat invocation; cross-skill handoff; agent delegation; hook/tool-event behavior;
MCP authentication/availability; missing executables; partial output; overwrite;
new session; source update; disable/uninstall; failure and unsupported requests.
Do not assume dry-run, rollback, reset, resume or cleanup exists.

## Required use-case format

Every use case contains:
1. Goal and realistic situation; linked component/feature/branch IDs.
2. Prerequisites and concrete safe sample inputs/files/settings. Label them as
   illustrative, not observed production data or a real execution record.
3. Exact actions in order, including the interface: Claude chat, UI, shell or event.
4. A usable example prompt, multi-turn transcript or automatic-event timeline.
5. For EVERY user turn, label explicit invocation, ordinary follow-up, UI action or
   fresh-session setup; explain the choice, current state, next actor and any wait.
6. Expected result/artifacts, filenames/formats and how the user verifies success.
7. Common failures, recovery/retry rules and any unsupported recovery feature.
8. Costs/resources, file/network side effects and irreversible effects where known.
9. Actual source/runtime evidence and any assumption or recommendation.

Use exact public commands only after confirming namespace and exposure. Do not
turn internal scripts, agent names, MCP names or plugin display names into slash
commands. Describe natural-language requests as such, not a formally parsed API.
Never publish a dangerous target command as safe without warning and context.
Use redacted example credentials; never copy actual user data into a tutorial.

## Multi-turn example convention

```text
Turn 1 - User [explicit invocation of verified component]
/<verified-plugin>:<verified-entrypoint> <concrete inputs and goal>

Agent [expected, illustrative]
<action, written artifact or precise question; say if waiting>

Turn 2 - User [ordinary follow-up to the same pending task]
<concrete answer or changed input>

Agent [expected, illustrative]
<next action and any change of state/artifacts>
```

This is a template, not a universal command grammar. Fill actual examples from
source. Independent cases must not assume state from another case without linking
a prerequisite. When switching components, include the exact artifact handoff.

## Automatic-event example convention

```text
Precondition: <verified enabled configuration and required dependency>
User/Agent action: <the ordinary action that emits the documented event>
Runtime event: <verified event and matching condition>
Handler: <actual configured handler; not a slash command>
Observable effect: <file, output, denial or external effect>
Next user action: <continue, inspect output, fix config or stop>
```

Mark inferred timing/ordering as unknown when official docs/source do not establish
it. Explain that the event could occur without invoking the plugin's main skill.

## Coverage reconciliation

| Component | Feature/branch/trigger | Use cases | Source evidence | Coverage/gap |
|---|---|---|---|---|

Every public capability and consequential automatic effect needs a worked case.
Every case must map to a supported feature or be explicitly RECOMMENDATION or
UNSUPPORTED. Traceable coverage is more useful than arbitrary case counts.

For eval plugins distinguish trigger-selection tests, output-quality grading,
structural checks and aggregation. Do not infer precision/recall, weighting,
custom-rubric ingestion or state-engine guarantees from the word benchmark.

## Version 3 operation-level completion gate

Apply references/operation-contract.md (relative to the writer root). A relevant
scenario must link to an OP card with complete typed action, parameter binding and
resend rules, prior/post-state, result invalidation, retry effects and evidence.
Inputs in a remote chapter do not substitute for per-action parameter instructions.
Check that follow-up vs explicit invocation is compared where runtime effects may
differ. Re-read sources for these claims; unknowns must not be silently resolved.
Render OP markers in USAGE.md; save operations.json and REVIEW.md in _audit/.
The structural check and semantic self-review are distinct gates. Report their
actual status, never convert a helper pass into an end-to-end quality claim.

# Behavioral evaluation kit - no Claude run claimed

## Purpose
Test the generated MANUAL, not just the read ledger. Six synthetic target fixtures
cover a multi-turn quiz, positional args, file-backed modes, dynamic data, a
multi-component plugin and missing source. They are development cases, not a
production benchmark or held-out set. The materializer never executes their code.

## Run a case
1. Use Python 3.10+ (or manually create sources from cases.json). From this writer's
   directory run the trusted materializer with a NEW external directory:

```text
python scripts/prepare_eval.py --case T02 --out C:/work/doc-evals/run-001
```

2. It writes input/target, REQUEST.md, run-record.json (NOT_RUN), and separate
   grading/expected.json and scorecard.json. Do not install/enable the target.
   Do not open the evaluation workspace as a loaded plugin. Existing host hooks
   still apply; use a disposable isolated review environment when necessary.
3. Start a fresh Claude Code LOCAL session with the writer installed. Copy the
   request from REQUEST.md into CHAT. Do not give grading data/answer keys to the
   writing agent. The SKILL scripts do not themselves start Claude or incur API
   calls. Desktop usage does not require the Claude CLI.
4. Record actual model/runtime versions, user prompt, source hashes and outputs.
   Save the real transcript or an honest observed-step record; redact secrets.
   Do not mark a runtime execution as completed until its artifacts exist.
5. Run scripts/check_manual.py on the generated USAGE.md and operations.json.
6. Independently inspect the candidate against input sources and grading assertions
   using rubric.md. Fill scorecard.json with actual manual quotes and source lines.
   Another LLM may assist but needs calibration; agreement is not ground truth.
7. Repeat unstable cases (e.g. 3 runs initially, not a statistical guarantee).
   Compare old/new writer with the same target, model, settings and limits in
   separate fresh sessions. No shared generated artifacts or answer leakage.
8. Add real installed-source snapshots and separately authored unseen cases before
   claiming production quality. Keep a held-out set out of authoring prompts.

For skill-document case T05, select input/target/skills/evaluate as the target and
include owning-plugin context. For plugin-document use the entire input/target.
The prepared request handles this selection. Expected snippets are comparison aids,
not complete example manuals. Use source line evidence for adjudication.

## What the included tests establish
Unit tests check materialization and the structural checker, including deliberate
invalid manuals. They do NOT call Claude or grade the semantic truth of a real
candidate. A structurally consistent lie may still pass; that negative control is
intentional and tested. Publish failures/unknowns as well as successes.

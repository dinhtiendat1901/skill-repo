# Semantic grading rubric for generated manuals

Grade actual USAGE.md, its operation cards and corresponding source, not attractive
formatting. The golden assertions in cases.json are fixture-specific, not universal
Claude rules. Evidence must identify candidate lines and supporting source lines.

## Critical failures override any numeric score
Target execution; fabricated citation; unsupported command/flag/namespace; omitted
required parameter in an action example; wrong resend/reuse/run binding; false
resume guarantee; hidden dangerous overwrite/duplicate effect; false complete-source
claim; concealed missing dependency; secret disclosure or wrong installed copy.
An accurately disclosed unknown is not fabrication. The missing-source case should
produce an honest INCOMPLETE manual, which can pass that case's expected behavior.

## Score dimensions
| Dimension | Weight | Full-credit requirement |
|---|---|---|
| Actionability | 20 | Exact surface/action, labeled turns, waiting and completion |
| Parameter lifecycle | 25 | Requirement/default/binding/resend/missing/effect for each input |
| State and results | 20 | Ownership, explicit handoff, reuse/invalidation/retry/overwrite |
| Runtime distinction | 15 | Follow-up vs invoke checked with version-aware evidence |
| Coverage and examples | 10 | Capabilities/scenarios/OP/use cases connected without invented features |
| Evidence and uncertainty | 10 | Actual citations, contradictions and limitations visible |

For each dimension give 0/0.5/1 of its weight with evidence. Recommended development
acceptance: no critical failure, all fixture-critical assertions satisfied, >=85/100.
This threshold is a project policy, NOT a standard or proof of reliability.
Treat unresolved critical judgments as INCONCLUSIVE, not PASS. Report raw scores,
critical failures, unknowns and counts separately. Do not discard difficult cases.

## Review discipline
The writer's own REVIEW.md is SELF_REVIEW, not independent grading. Fill
scorecard.json after looking at actual outputs. Never mark NOT_RUN as zero-cost
success. Use separate source-aware reviewers for disagreements; judge correctness
rather than exact prose. Test whether a reader can identify the next action and
all required values without reconstructing instructions from scattered chapters.

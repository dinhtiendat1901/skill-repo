# Changelog

## 3.0.0 - 2026-10-29
- Rename `plugin-usage-guide-writer` 2.0.0 to `plugin-document` (directory, YAML name, examples and UI metadata).
- Preserve the original source-audit helper and inherited unit tests.
- Require per-operation action/parameter/state cards, resend/binding/default rules,
  postconditions, stale-result handling and per-dimension runtime comparisons.
- Add operations.json, the structural check_manual.py helper and explicit REVIEW.md.
- Keep structural checking separate from semantic correctness and runtime execution.
- Add six materializable representative fixtures, expectations, semantic rubric,
  fresh-session evaluation protocol and NOT_RUN scorecards.
- Extend author-facing and Vietnamese user guides; ordinary follow-up and fresh-session
  rules are explicit. No native resume/reset command and no workflow engine added.
- Keep original default output directories for compatibility; legacy audit paths must
  be supplied explicitly and missing v3 artifacts generated from checked source.

This is a full package upgrade, not just a patch. Names of downloaded ZIPs are unique.

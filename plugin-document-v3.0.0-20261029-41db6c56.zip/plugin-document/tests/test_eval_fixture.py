"""Fixture preparation only; never executes a target or calls Claude."""
from pathlib import Path
import hashlib
import importlib.util
import json
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('prepare_eval_local',ROOT/'scripts/prepare_eval.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

class FixtureTests(unittest.TestCase):
    def test_all_six_cases_materialize_without_execution(self):
        with tempfile.TemporaryDirectory() as t:
            for case in ['T01','T02','T03','T04','T05','T06']:
                out=Path(t)/case
                result=m.prepare(case,out)
                self.assertEqual(result['status'],'NOT_RUN')
                record=json.loads((out/'run-record.json').read_text())
                self.assertEqual(record['status'],'NOT_RUN')
                for rel,digest in record['source_sha256'].items():
                    raw=(out/'input/target'/rel).read_bytes()
                    self.assertEqual(hashlib.sha256(raw).hexdigest(),digest)
                self.assertFalse((out/'output/USAGE.md').exists())
                self.assertTrue((out/'grading/expected.json').exists())
                self.assertTrue((out/'grading/scorecard.json').exists())
    def test_request_does_not_include_gold_answers(self):
        with tempfile.TemporaryDirectory() as t:
            out=Path(t)/'run';m.prepare('T02',out)
            request=(out/'REQUEST.md').read_text()
            self.assertNotIn('assertions',request)
            self.assertNotIn('No --target/--focus',request)
    def test_t05_skill_vs_plugin_scope(self):
        with tempfile.TemporaryDirectory() as t:
            out=Path(t)/'run';m.prepare('T05',out)
            request=(out/'REQUEST.md').read_text()
            self.assertEqual('input/target/skills/evaluate' in request,ROOT.name=='skill-document')
    def test_existing_run_refused(self):
        with tempfile.TemporaryDirectory() as t:
            with self.assertRaises(ValueError):m.prepare('T01',Path(t))
    def test_unknown_id(self):
        with tempfile.TemporaryDirectory() as t:
            with self.assertRaises(ValueError):m.prepare('no-such-case',Path(t)/'run')
    def test_inside_package_refused(self):
        with self.assertRaises(ValueError):m.prepare('T01',ROOT/'eval-output-must-not-exist')
    def test_path_traversal_refused(self):
        for value in ['../escape','/absolute','C:/outside','x\\escape']:
            with self.subTest(value=value):
                with self.assertRaises(ValueError):m.safe_relative(value)
    def test_valid_hidden_relative_path(self):
        self.assertEqual(str(m.safe_relative('.claude-plugin/plugin.json')),'.claude-plugin/plugin.json')
    def test_missing_dependency_remains_missing(self):
        with tempfile.TemporaryDirectory() as t:
            out=Path(t)/'run';m.prepare('T06',out)
            self.assertEqual(len(list((out/'input/target').rglob('policy.md'))),0)
    def test_scorecard_is_not_a_passing_grade(self):
        with tempfile.TemporaryDirectory() as t:
            out=Path(t)/'run';m.prepare('T03',out)
            card=json.loads((out/'grading/scorecard.json').read_text())
            self.assertEqual(card['status'],'NOT_RUN');self.assertIsNone(card['critical_failure'])
            self.assertTrue(all(x['result']=='NOT_RUN' for x in card['assertions']))

if __name__=='__main__':unittest.main()

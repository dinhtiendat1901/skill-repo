"""Deterministic validator tests using AUTHORED controls, not Claude outputs."""
from pathlib import Path
import copy
import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('check_manual_local',ROOT/'scripts/check_manual.py')
m=importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

class ContractTests(unittest.TestCase):
    def setUp(self):
        self.data=json.loads((ROOT/'assets/operations-example.json').read_text(encoding='utf-8'))
        self.manual=(ROOT/'tests/controls/authored-manual.md').read_text(encoding='utf-8')
    def check(self): return m.validate(self.data,self.manual)
    def test_authored_control_passes_structure_not_semantics(self):
        r=self.check(); self.assertTrue(r['structural_ok'],r['errors']); self.assertEqual(r['semantic_evaluation'],'NOT_PERFORMED')
    def test_incomplete_guide_can_pass_honestly(self):
        self.assertEqual(self.check()['coverage_status'],'incomplete'); self.assertTrue(self.check()['warnings'])
    def test_wrong_root(self): self.assertFalse(m.validate([],self.manual)['structural_ok'])
    def test_schema_version(self):
        self.data['schema_version']=2; self.assertFalse(self.check()['structural_ok'])
    def test_boolean_version_rejected(self):
        self.data['schema_version']=True; self.assertFalse(self.check()['structural_ok'])
    def test_missing_operation(self):
        self.data['operations']=[]; self.assertFalse(self.check()['structural_ok'])
    def test_missing_action(self):
        self.data['operations'][0]['action']=''; self.assertFalse(self.check()['structural_ok'])
    def test_missing_resend(self):
        del self.data['operations'][0]['parameters'][0]['resend']; self.assertFalse(self.check()['structural_ok'])
    def test_missing_effective_time(self):
        del self.data['operations'][0]['parameters'][0]['effective_when']; self.assertFalse(self.check()['structural_ok'])
    def test_missing_binding(self):
        del self.data['operations'][0]['parameters'][0]['binding']; self.assertFalse(self.check()['structural_ok'])
    def test_manual_binding_must_be_visible(self):
        v=self.data['operations'][0]['parameters'][0]['binding']
        self.manual=self.manual.replace(v,'Binding not explained.');self.assertFalse(self.check()['structural_ok'])
    def test_manual_missing_value_rule_must_be_visible(self):
        v=self.data['operations'][0]['parameters'][0]['missing_behavior']
        self.manual=self.manual.replace(v,'Unknown.');self.assertFalse(self.check()['structural_ok'])
    def test_manual_runtime_difference_must_be_visible(self):
        v=self.data['operations'][0]['runtime_comparison']['arguments']['details']
        self.manual=self.manual.replace(v,'The two routes are always identical.');self.assertFalse(self.check()['structural_ok'])
    def test_manual_next_actor_must_be_visible(self):
        v=self.data['operations'][0]['next_actor'];self.manual=self.manual.replace(v,'No next step described.');self.assertFalse(self.check()['structural_ok'])
    def test_unknown_resend_allowed_when_explained(self):
        self.data['operations'][0]['parameters'][0]['resend']='unknown'; self.assertTrue(self.check()['structural_ok'])
    def test_invalid_resend(self):
        self.data['operations'][0]['parameters'][0]['resend']='maybe'; self.assertFalse(self.check()['structural_ok'])
    def test_missing_scenario(self):
        self.data['scenarios']=self.data['scenarios'][1:]; self.assertFalse(self.check()['structural_ok'])
    def test_covered_without_operation(self):
        self.data['scenarios'][0]['operation_ids']=[]; self.assertFalse(self.check()['structural_ok'])
    def test_unknown_operation_reference(self):
        self.data['scenarios'][0]['operation_ids']=['OP99']; self.assertFalse(self.check()['structural_ok'])
    def test_empty_na_reason(self):
        self.data['scenarios'][1].update(status='not_applicable',reason=''); self.assertFalse(self.check()['structural_ok'])
    def test_duplicate_operation(self):
        self.data['operations'].append(copy.deepcopy(self.data['operations'][0])); self.assertFalse(self.check()['structural_ok'])
    def test_duplicate_parameter(self):
        self.data['operations'][0]['parameters'].append(copy.deepcopy(self.data['operations'][0]['parameters'][0])); self.assertFalse(self.check()['structural_ok'])
    def test_duplicate_scenario(self):
        self.data['scenarios'].append(copy.deepcopy(self.data['scenarios'][0])); self.assertFalse(self.check()['structural_ok'])
    def test_missing_card(self):
        self.manual=self.manual.replace('OP01:BEGIN','OP02:BEGIN'); self.assertFalse(self.check()['structural_ok'])
    def test_duplicate_card(self):
        self.manual+=self.manual; self.assertFalse(self.check()['structural_ok'])
    def test_manual_action_mismatch(self):
        self.manual=self.manual.replace('src/b.ts security','--focus security'); self.assertFalse(self.check()['structural_ok'])
    def test_manual_resend_mismatch(self):
        self.manual=self.manual.replace('Supply target again for every new review.','The previous target is reused.'); self.assertFalse(self.check()['structural_ok'])
    def test_manual_state_mismatch(self):
        self.manual=self.manual.replace(self.data['operations'][0]['state_after'],'An earlier review resumes.'); self.assertFalse(self.check()['structural_ok'])
    def test_follow_up_cannot_be_slash_action(self):
        self.data['operations'][0]['interaction']='follow_up'; self.assertFalse(self.check()['structural_ok'])
    def test_missing_runtime_dimension(self):
        del self.data['operations'][0]['runtime_comparison']['hooks']; self.assertFalse(self.check()['structural_ok'])
    def test_missing_evidence(self):
        self.data['operations'][0]['evidence']=[]; self.assertFalse(self.check()['structural_ok'])
    def test_bad_source_citation_shape(self):
        self.data['operations'][0]['evidence']=['[SOURCE-CODE; trust me]']; self.assertFalse(self.check()['structural_ok'])
    def test_runtime_reference_needs_date(self):
        self.data['operations'][0]['runtime_comparison']['hooks']['evidence']=['[RUNTIME-DOC; https://code.claude.com/docs/en/hooks]']; self.assertFalse(self.check()['structural_ok'])
    def test_gaps_cannot_be_complete(self):
        self.data['coverage_status']='complete_within_scope'; self.assertFalse(self.check()['structural_ok'])
    def test_incomplete_marker_required(self):
        self.manual=self.manual.replace('INCOMPLETE','Complete'); self.assertFalse(self.check()['structural_ok'])
    def test_internal_consistency_does_not_prove_truth(self):
        old=self.data['operations'][0]['result_policy']; false='Every prior result is permanently deleted.'
        self.data['operations'][0]['result_policy']=false; self.manual=self.manual.replace(old,false)
        r=self.check(); self.assertTrue(r['structural_ok']); self.assertEqual(r['semantic_evaluation'],'NOT_PERFORMED')
    def test_plugin_scenarios_required(self):
        self.data['target']['kind']='plugin'
        self.data['scenarios']=[s for s in self.data['scenarios'] if s['id'] not in m.PLUGIN_SCENARIOS]
        self.assertFalse(self.check()['structural_ok'])
    def test_whitespace_normalization(self):
        self.manual=self.manual.replace('src/b.ts security','src/b.ts    security'); self.assertTrue(self.check()['structural_ok'])
    def test_utf8_content(self):
        self.manual+='\nGhi chu: \u0111\u00e2y l\u00e0 v\u00ed d\u1ee5.\n'; self.assertTrue(self.check()['structural_ok'])
    def test_cli_valid_and_no_overwrite(self):
        with tempfile.TemporaryDirectory() as t:
            d=Path(t); ops=d/'operations.json'; manual=d/'USAGE.md'; out=d/'report.json'
            ops.write_text(json.dumps(self.data),encoding='utf-8');manual.write_text(self.manual,encoding='utf-8')
            command=[sys.executable,str(ROOT/'scripts/check_manual.py'),'--operations',str(ops),'--manual',str(manual),'--out',str(out)]
            r=subprocess.run(command,capture_output=True,text=True,timeout=15)
            self.assertEqual(r.returncode,0,r.stdout+r.stderr); self.assertTrue(out.exists())
            r=subprocess.run(command,capture_output=True,text=True,timeout=15);self.assertEqual(r.returncode,1)
    def test_cli_invalid_json(self):
        with tempfile.TemporaryDirectory() as t:
            d=Path(t); ops=d/'bad.json';ops.write_text('bad',encoding='utf-8')
            r=subprocess.run([sys.executable,str(ROOT/'scripts/check_manual.py'),'--operations',str(ops),'--manual',str(ROOT/'tests/controls/authored-manual.md')],capture_output=True,text=True,timeout=15)
            self.assertEqual(r.returncode,1)
    def test_cli_structural_failure_exit_two(self):
        with tempfile.TemporaryDirectory() as t:
            d=Path(t);ops=d/'ops.json';self.data['operations'][0]['parameters']=None;ops.write_text(json.dumps(self.data),encoding='utf-8')
            r=subprocess.run([sys.executable,str(ROOT/'scripts/check_manual.py'),'--operations',str(ops),'--manual',str(ROOT/'tests/controls/authored-manual.md')],capture_output=True,text=True,timeout=15)
            self.assertEqual(r.returncode,2)

if __name__=='__main__': unittest.main()

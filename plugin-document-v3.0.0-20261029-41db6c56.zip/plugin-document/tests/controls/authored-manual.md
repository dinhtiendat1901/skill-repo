# Authored checker control (not LLM output)

INCOMPLETE: a partial synthetic example; NOT a runtime test.

<!-- OP01:BEGIN -->
### OP01 - Review a different file using the security focus.

**component:** review-suite / mini-review
**preconditions:** The new file must exist and be readable; confirm the installed command name.
**interaction:** invoke
**interface:** formal
**invocation_policy:** required
**policy_reason:** The fixture author requires a new invocation for a new file or focus; this is an instruction, not a runtime state gate.

```text
/review-suite:mini-review src/b.ts security
```

Both positional values are required; do not add invented named flags.

#### target
**name:** target
**form:** $0
**requirement:** Required for every new review; no default.
**binding:** Read the current explicit invocation, not a previous turn.
**resend:** yes
**resend_rule:** Supply target again for every new review.
**example:** src/b.ts
**missing_behavior:** Ask for the missing value; do not silently reuse it.
**effective_when:** Applies to the new review only.
**state_effect:** Does not change the earlier review result.
**evidence:** [SOURCE-INSTRUCTION; TARGET/SKILL.md:L7-L11]
#### focus
**name:** focus
**form:** $1
**requirement:** Required for every new review; no default.
**binding:** Read the current explicit invocation, not a previous turn.
**resend:** yes
**resend_rule:** Supply focus again for every new review.
**example:** security
**missing_behavior:** Ask for the missing value; do not silently reuse it.
**effective_when:** Applies to the new review only.
**state_effect:** Does not change the earlier review result.
**evidence:** [SOURCE-INSTRUCTION; TARGET/SKILL.md:L7-L11]
**state_after:** A new review of src/b.ts is requested.
**result_policy:** No overwrite or automatic state-reuse contract is specified; keep prior findings distinct.
**next_actor:** Agent reviews, or asks for missing access/input; the user waits.
**completion_signal:** A review response about src/b.ts, or a disclosed blocker.
**failure_action:** Resolve the reported missing input/access; do not invent a resume command.
**limitations:** This is a partial synthetic contract, not a real runtime test.
[SOURCE-INSTRUCTION; TARGET/SKILL.md:L7-L11]
**arguments (different):** A new review requires target and focus again. A follow-up only explains prior findings. [SOURCE-INSTRUCTION; TARGET/SKILL.md:L7-L11]
**preprocessing (unknown):** Runtime behavior not verified in this illustrative contract. [UNKNOWN; Installed runtime and host configuration were not inspected in this synthetic example]
**permissions (unknown):** Runtime behavior not verified in this illustrative contract. [UNKNOWN; Installed runtime and host configuration were not inspected in this synthetic example]
**hooks (unknown):** Runtime behavior not verified in this illustrative contract. [UNKNOWN; Installed runtime and host configuration were not inspected in this synthetic example]
**context (unknown):** Runtime behavior not verified in this illustrative contract. [UNKNOWN; Installed runtime and host configuration were not inspected in this synthetic example]
**state_restore (unknown):** Runtime behavior not verified in this illustrative contract. [UNKNOWN; Installed runtime and host configuration were not inspected in this synthetic example]
<!-- OP01:END -->


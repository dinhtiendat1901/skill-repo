# Manual review record

- Manual and operations paths: {{PATHS}}
- Target snapshot: {{SNAPSHOT}}
- Review date / reviewer: {{DATE_AND_ID}}
- Review type: {{SELF_REVIEW_OR_INDEPENDENT_REVIEW_OR_NOT_RUN}}
- Source coverage: {{RESULT_WITH_GAPS}}
- Structural check: {{ACTUAL_REPORT_PATH_AND_RESULT_OR_NOT_RUN}}
- Independent semantic evaluation: NOT_RUN unless separately performed and recorded.
- Claude Code end-to-end test: NOT_RUN unless actual execution evidence is provided.

| Operation | Checks actually performed | Guide location | Source/runtime evidence | Finding | Correction / unresolved gap |
|---|---|---|---|---|---|
{{ROWS_NOT_JUST_CHECKBOXES}}

## Conclusion
{{READY_WITHIN_STATIC_SCOPE_OR_INCOMPLETE_AND_WHY}}
A structural pass or self-review is not proof of runtime behavior or independent accuracy.

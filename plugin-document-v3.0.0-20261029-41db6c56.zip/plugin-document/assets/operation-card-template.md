<!-- Authoring template, translate headings. Preserve unique OP markers.
Copy this card for each consequential action; replace all placeholders. -->
<!-- OP01:BEGIN -->
### OP01 - {{GOAL}}

**Component / situation:** {{COMPONENT_AND_SITUATION}}
**Before acting:** {{PRECONDITIONS}}
**Interaction and surface:** {{MODE_AND_CHAT_OR_UI_OR_SHELL_OR_EVENT}}
**Invocation policy and why:** {{REQUIRED_RECOMMENDED_OPTIONAL_NA_UNKNOWN_AND_EVIDENCE}}

**What to type or do (illustrative values, replace identified paths):**
```text
{{COMPLETE_SUPPORTED_ACTION}}
```
{{LITERAL_SYNTAX_VS_FREE_TEXT_AND_REPLACEABLE_VALUES}}

**Parameters for THIS action:**
| Parameter / syntax | Required/default | Value source / binding | Send again? Why? | Missing value | Example / path base | Effective when / state effect | Evidence |
|---|---|---|---|---|---|---|---|
{{ONE_ROW_PER_PARAMETER_OR_EXPLICIT_NONE}}

**After acting:** {{STATE_AFTER}}
**Existing results / output locations:** {{RESULT_POLICY}}
**Who acts next / wait / approval:** {{NEXT_ACTOR}}
**How to recognize completion:** {{COMPLETION_SIGNAL}}
**On failure:** {{FAILURE_ACTION}}

**Would an ordinary follow-up be equivalent to invoking again?**
| Dimension | Different/equivalent/N/A/unknown | Explanation and evidence |
|---|---|---|
{{ARGUMENTS_PREPROCESSING_PERMISSIONS_HOOKS_CONTEXT_STATE_RESTORE}}

**Evidence and limits:** {{LABELED_EVIDENCE_AND_LIMITATIONS}}
<!-- OP01:END -->

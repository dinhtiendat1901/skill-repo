# skill-document - Hướng dẫn sử dụng

Phiên bản **3.0.0**, dành cho Claude Code. Đổi tên và nâng cấp từ `usage-guide-writer` 1.0.0.
Đây vẫn là một **Skill độc lập**, không phải plugin marketplace.
Mục tiêu: đọc source của skill và viết tài liệu Markdown tiếng Việt.

## 1. Cài đặt hoặc chuyển từ bản cũ

Giải nén file ZIP riêng của skill-document. Chép nguyên thư mục `skill-document` vào **một** phạm vi:

```text
Cá nhân: %USERPROFILE%\.claude\skills\skill-document\SKILL.md
Project: <project>\.claude\skills\skill-document\SKILL.md
```

Không lồng thêm một thư mục skill-document. Mở Local Session mới trong
project bạn muốn lưu tài liệu, gõ `/skill-document` ở ô chat.
Không nhập lệnh slash trong PowerShell. Không cần cài Claude CLI riêng.

Bản cũ có thể còn cài song song nhưng không tự chuyển sang tên mới.
Sau khi kiểm tra bản mới hoạt động, bạn có thể chuyển thư mục cũ ra
ngoài `.claude/skills/` để tránh hai bản cùng tự kích hoạt.
Không xóa các tài liệu hoặc `_audit/` đã tạo. Không tự đổi tên checkpoint.

## 2. Single-turn: một yêu cầu để bắt đầu

```text
/skill-document tạo tài liệu hướng dẫn sử dụng cho skill skill-creator đã cài.
```

Prompt ngắn đủ để bắt đầu workflow mặc định. Agent phải xác định bản cài,
đọc source, phân tích thao tác, viết tài liệu và rà soát. Không cần nhắc
lại quy trình. Single-turn không có nghĩa một lần gọi model hoặc chắc chắn
hoàn tất trong một phản hồi. Agent có thể hỏi lại khi trùng tên, thiếu
quyền, thiếu source hoặc output cũ có nguy cơ bị ghi đè.

Để xác định rõ source và output, dùng:

```text
/skill-document
Đối tượng: C:/work/sources/my-target
Output: C:/work/manuals/my-target/USAGE.md
Ngôn ngữ: tiếng Việt.
Chỉ phân tích source, không chạy đối tượng.
```

Đổi các đường dẫn ví dụ thành đường dẫn thật. Các nhãn Output,
Đối tượng là ngôn ngữ tự nhiên, không phải flags hay API có parser.
Skill này không định nghĩa lệnh con `resume`, `reset` hoặc `--rubric`.

## 3. Multi-turn: khi nào prompt tiếp, khi nào invoke lại?

| Tình huống | Thao tác | Dữ liệu cần gửi |
|---|---|---|
| Agent hỏi chọn bản cài | Trả lời bình thường | Tên/đường dẫn bản được chọn |
| Bổ sung use case cho cùng tài liệu | Prompt bình thường | Phần cần sửa, output nếu có nhiều tài liệu |
| Source thay đổi | Yêu cầu kiểm tra snapshot và cập nhật | Source, bản mới và output liên quan |
| Đối tượng khác | Nên invoke mới, output riêng | Target mới, output nếu muốn |
| Session mới | Invoke mới để đọc hồ sơ cũ | Source và thư mục output/_audit cũ |
| Gọi lại trong cùng session | Không tự động reset | Nói rõ tiếp tục hay phân tích lại |

Ví dụ prompt tiếp, **không cần slash command**:

```text
Tiếp tục tài liệu hiện tại. Bổ sung ví dụ khi đổi dataset sau lần test đầu.
Chỉ rõ tham số nào phải gửi lại và kết quả nào không còn hợp lệ.
Không bịa thêm chức năng nếu source không có.
```

Ví dụ sang session mới:

```text
/skill-document
Tiếp tục tài liệu của C:/work/sources/my-target.
Output và hồ sơ cũ: C:/work/manuals/my-target/
Đọc _audit/ANALYSIS.md, kiểm tra snapshot rồi tiếp tục phần chưa xong.
```

Đây là instructions của writer, không phải bảo đảm của Workflow Engine.
File checkpoint phải còn và đọc được. Bản cũ chưa có operations.json:
Agent phải bổ sung theo source, không giả vờ file đã có.

## 4. Output và cách đọc

Mặc định: `docs/skill-guides/<target-id>/USAGE.md` (bản plugin thêm snapshot vào ID).
Đầu ra phải nằm ngoài source được phân tích.

| File | Thông tin |
|---|---|
| USAGE.md | Tài liệu chính: chức năng, thao tác, tham số, state, use case, ví dụ và dẫn chứng |
| _audit/operations.json | Các thẻ OP: input/resend/binding/state/effects để đối chiếu với Markdown |
| _audit/ANALYSIS.md | Target, snapshot, quyết định, tiến độ và bước tiếp theo |
| _audit/inventory.json | Kiểm kê file, hash, phân loại; có thể cần nhiều manifest cho nhiều root |
| _audit/read-ledger.json | Phạm vi dòng đã đọc được ghi nhận |
| _audit/manual-check.json | Kết quả script kiểm tra cấu trúc; không phải điểm đúng/sai ngữ nghĩa |
| _audit/REVIEW.md | Agent tự đối chiếu các thao tác với source, ghi lỗi và điểm chưa rõ |

Khi không có Python, Agent dùng file tools và ghi `manual-check.md` với
nhãn MANUAL_CHECK_ONLY thay cho kết quả script. Khi kiểm tra lại, report có
thể có tên mới để không ghi đè; ANALYSIS.md ghi đường dẫn mới nhất.
Bạn chỉ cần đọc USAGE.md để sử dụng target; không cần tự ghép JSON.

## 5. Những thay đổi quan trọng của bản 3

Mỗi thao tác phải có câu nhập đầy đủ, từng tham số cần gửi lại hay
đọc từ file, thời điểm áp dụng, kết quả bị vô hiệu và người làm
bước tiếp theo. Phải so sánh follow-up với invoke về arguments, preprocessing,
permissions, hooks, context và khôi phục. Không tự áp quy tắc writer lên target.

## 6. Giới hạn và kiểm thử

Phân tích tĩnh không chạy target. Skill không cài, enable, reload hay test
source được phân tích. Nó không tạo sandbox; hooks đã bật ở host vẫn
có thể hoạt động. Thiếu source quan trọng thì tài liệu phải ghi INCOMPLETE.

Helper kiểm tra cấu trúc và một số chuỗi nội dung khớp nhau. Nội dung sai
nhưng nhất quán vẫn có thể vượt qua. REVIEW.md là tự rà soát, không
phải chấm độc lập. Chưa có kiểm thử hành vi end-to-end trong Claude Code
được thực hiện khi xây dựng bản này. Xem VALIDATION.md.

Bộ `evals/` có 6 target giả lập, expected behavior, rubric và hướng dẫn chạy
trong session mới. Đó là bộ kiểm thử cần chạy, không phải kết quả đạt.
Python 3.10+ chỉ cần cho helper; không cần thư viện ngoài.

Nguồn Runtime: https://code.claude.com/docs/en/skills (đối chiếu 2026-10-29).

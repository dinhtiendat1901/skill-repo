# Runtime lookup guide

Official primary sources (checked 2026-10-29; re-check for the installed version):
- https://code.claude.com/docs/en/skills#skill-content-lifecycle
- https://code.claude.com/docs/en/skills#pass-arguments-to-skills
- https://code.claude.com/docs/en/skills#inject-dynamic-context
- https://code.claude.com/docs/en/skills#pre-approve-tools-for-a-skill
- https://code.claude.com/docs/en/skills#run-skills-in-a-subagent
- https://code.claude.com/docs/en/hooks#userpromptexpansion
- https://code.claude.com/docs/en/hooks#pretooluse
- https://code.claude.com/docs/en/plugins-reference
- https://code.claude.com/docs/en/permissions

Review implications, not universal policies: persisted instructions and temporary
tool approval differ; substitution/preprocessing takes place on invocation;
forked execution introduces a context boundary. Direct slash expansion and a
model's Skill tool call can encounter different configured hooks. The actual
installed version, configuration, permission policy and successful preprocessing
matter. A new invoke is not inherently reset, resume or permission bypass.

These links are evidence lookup starting points, not target feature declarations.
Do not freeze exact compaction budgets or infer flags from generic documentation.
If unavailable, label runtime claims UNKNOWN and preserve verified source facts.

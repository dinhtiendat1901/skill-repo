# Validation record - skill-document 3.0.0

Build: 2026-10-29. Environment: Linux x86_64, Python 3.13.5.

## Actually performed
- Recovered and checked the original archive; upgraded a copy without changing the original.
- Renamed the directory, SKILL.md name, user invocation examples and UI metadata.
- Preserved the original source_audit.py byte-for-byte and 28 inherited tests.
- Added 42 manual-contract tests and 10 fixture-preparation tests.
- Ran all **80/80 tests successfully**. See tests/last-test-run.txt.
- The contract tests check absent binding/resend/missing-input/timing, incorrect
  manual examples, missing runtime comparisons, scenario mappings and no silent
  report overwrite. They also demonstrate that a consistent false claim can pass.
- Prepared all six synthetic cases without invoking/installing/executing target code.
  Scorecards and run receipts stay NOT_RUN; no fabricated model result is written.
- Validated entrypoint/name/description using the installed skill-creator validator.

## Release verification
The release build checks UTF-8 text, Markdown fence balance, referenced package
paths, no caches, one SKILL.md entrypoint, ZIP integrity/path containment and exact
file-byte equality after extraction. It reruns the test suite in a clean extracted
copy. The delivered archive is emitted only if these checks succeed. External
release-record.json records the archive checksum and clean-test outcome.

## What is NOT established
- No installation/invocation inside Claude Code Desktop, IDE or CLI occurred here.
- No native Windows run was performed; portability is intended, not Windows-verified.
- No actual Claude-generated manual was independently semantically graded.
- No production benchmark, security certification or complete behavior guarantee.
- 42 contract tests use authored partial manuals; these are not writer outputs.
- Source hashes/ranges do not prove LLM comprehension. The new checker validates
  structure and text agreement, not source truth or correctness of all claims.
- REVIEW.md produced during normal use is self-review unless independently assessed.

## Behavioral evaluation included, not executed
`evals/cases.json` contains six synthetic development fixtures with expected
behaviors and assertions. `scripts/prepare_eval.py` materializes them and separate
scorecards. See evals/README.md and evals/rubric.md for actual isolated Claude runs.
The fixtures were seen during authoring; they are not an unseen holdout or real
production repository dataset. Add independent cases before claiming generalization.
The inherited tests/behavioral-cases.md remains an additional NOT_RUN test plan.

## Reproduce code checks
```text
python -m unittest discover -s tests -p "test_*.py" -v
```
Python 3.10+ standard library only. No network, Claude account or target execution.

The plugin suite includes the skill suite's shared tests; their totals must not be
reported as 172 independent behavioral cases.

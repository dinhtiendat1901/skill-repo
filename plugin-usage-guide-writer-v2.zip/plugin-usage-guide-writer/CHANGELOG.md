# Changelog

## 2.0.0 - 2026-10-27 - Plugin documentation variant

Derived from `usage-guide-writer` 1.0.0. New standalone skill name:
`plugin-usage-guide-writer`. Existing skill-only installation remains compatible
and may coexist. This update delivers a complete package, not a patch.

- Expands the audit boundary to the entire selected plugin, including sibling
  skills, commands, agents, hooks, integrations, configuration and custom components.
- Adds a component registration/capability map and cross-component state handoffs.
- Separates manual commands, delegation, internal helpers and automatic effects.
- Adds per-component lifecycle guidance and installation/update/removal implications.
- Extends use cases with event timelines and registration/configuration edge cases.
- Preserves full-source reading, path/line evidence, unknowns, context checkpoints,
  safe static-only inspection, default Vietnamese output and all original helper tests.
- Adds plugin-wide inventory tests and an expanded behavioral acceptance plan.
- Retains the generic helper without presenting it as a schema/runtime validator.
- Adds a persistent audit checkpoint template and official runtime lookup references.
- Changes the default output to `docs/plugin-guides/<id-and-snapshot>/USAGE.md`.

No automatic migration of old audit workspaces is performed. A skill-only audit
cannot be relabeled as a complete plugin audit; inventory the whole plugin and
read all additional source before making that coverage claim.

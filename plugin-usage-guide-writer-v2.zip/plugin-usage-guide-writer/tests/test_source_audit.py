"""Deterministic tests for the optional audit helper, not Claude behavior."""
from __future__ import annotations

import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

SCRIPT = Path(__file__).resolve().parents[1] / 'scripts' / 'source_audit.py'
spec = importlib.util.spec_from_file_location('source_audit', SCRIPT)
assert spec and spec.loader
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)


class AuditTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.base = Path(self.tmp.name)
        self.root = self.base / 'target'
        self.root.mkdir()
        (self.root / 'SKILL.md').write_text('---\nname: example\n---\nAsk a question.\n', encoding='utf-8')

    def rows(self, value):
        return {r['path']: r for r in value['files']}

    def ledger(self, value):
        records = []
        for entry in value['files']:
            text = entry['kind'] == 'text'
            records.append({
                'path': entry['path'], 'status': 'read' if text else 'classified',
                'ranges': [[1, entry['lines']]] if text and entry['lines'] else [],
                'notes': 'Test fixture classification, not a model reading claim.',
            })
        return {'snapshot_id': value['snapshot_id'], 'files': records}

    def test_inventory_includes_hidden_and_unreferenced_files(self):
        (self.root / '.hidden').write_text('hidden', encoding='utf-8')
        (self.root / 'unused.py').write_text('x = 1\n', encoding='utf-8')
        self.assertEqual(set(self.rows(mod.inventory(self.root))), {'SKILL.md', '.hidden', 'unused.py'})

    def test_vcs_exclusion_is_explicit(self):
        (self.root / '.git').mkdir()
        (self.root / '.git' / 'objects').mkdir()
        rows = self.rows(mod.inventory(self.root))
        self.assertEqual(rows['.git']['kind'], 'vcs_metadata')
        self.assertNotIn('.git/objects', rows)
        self.assertIn('NOT inventoried', rows['.git']['reason'])

    def test_sensitive_filenames_not_read(self):
        (self.root / '.env').write_text('TOKEN=SECRET_SENTINEL', encoding='utf-8')
        rows = self.rows(mod.inventory(self.root))
        self.assertEqual(rows['.env']['kind'], 'protected')
        self.assertNotIn('sha256', rows['.env'])
        self.assertNotIn('SECRET_SENTINEL', json.dumps(rows))

    def test_environment_example_is_readable(self):
        (self.root / '.env.example').write_text('TOKEN=example\n', encoding='utf-8')
        self.assertEqual(self.rows(mod.inventory(self.root))['.env.example']['kind'], 'text')

    def test_binary_and_unsupported_text_encoding(self):
        (self.root / 'icon.bin').write_bytes(b'\x00\x01\xff')
        (self.root / 'legacy.md').write_bytes(b'\xffhello')
        rows = self.rows(mod.inventory(self.root))
        self.assertEqual(rows['icon.bin']['kind'], 'binary')
        self.assertEqual(rows['legacy.md']['kind'], 'unreadable_text')

    def test_utf16_and_utf8_bom(self):
        (self.root / 'utf16.md').write_bytes('H\u01b0\u1edbng d\u1eabn\nTwo\n'.encode('utf-16'))
        (self.root / 'bom.md').write_bytes(b'\xef\xbb\xbfOne\r\nTwo\r\n')
        value = mod.inventory(self.root)
        self.assertEqual(self.rows(value)['utf16.md']['lines'], 2)
        out = mod.read_chunk(value, 'utf16.md')
        self.assertEqual(out['lines'][0]['text'], 'H\u01b0\u1edbng d\u1eabn')
        self.assertEqual(self.rows(value)['bom.md']['lines'], 2)

    def test_large_file_not_silently_truncated(self):
        (self.root / 'large.txt').write_text('x' * 1000, encoding='utf-8')
        row = self.rows(mod.inventory(self.root, 100))['large.txt']
        self.assertEqual(row['kind'], 'too_large')
        self.assertNotIn('lines', row)

    def test_snapshot_stable_for_unchanged_files(self):
        self.assertEqual(mod.inventory(self.root)['snapshot_id'], mod.inventory(self.root)['snapshot_id'])

    def test_source_cannot_be_overwritten_by_manifest(self):
        value = mod.inventory(self.root)
        with self.assertRaises(mod.AuditError):
            mod.save_manifest(value, self.root / 'inventory.json')
        self.assertFalse((self.root / 'inventory.json').exists())

    def test_manifest_no_silent_overwrite(self):
        value = mod.inventory(self.root)
        out = self.base / 'manifest.json'
        mod.save_manifest(value, out)
        with self.assertRaises(mod.AuditError):
            mod.save_manifest(value, out)
        mod.save_manifest(value, out, overwrite=True)
        self.assertEqual(mod.load_manifest(out)['snapshot_id'], value['snapshot_id'])

    def test_manifest_integrity(self):
        value = mod.inventory(self.root)
        value['files'][0]['lines'] = 999
        out = self.base / 'bad.json'
        out.write_text(json.dumps(value), encoding='utf-8')
        with self.assertRaises(mod.AuditError):
            mod.load_manifest(out)

    def test_paging_through_eof(self):
        value = mod.inventory(self.root)
        first = mod.read_chunk(value, 'SKILL.md', 1, 2)
        self.assertEqual(first['end_line'], 2)
        self.assertEqual(first['next_start_line'], 3)
        second = mod.read_chunk(value, 'SKILL.md', 3, 2)
        self.assertEqual(second['end_line'], 4)
        self.assertIsNone(second['next_start_line'])

    def test_empty_file(self):
        (self.root / 'empty.md').touch()
        value = mod.inventory(self.root)
        out = mod.read_chunk(value, 'empty.md')
        self.assertEqual(out['lines'], [])
        self.assertIsNone(out['next_start_line'])
        self.assertTrue(mod.check_ledger(value, self.ledger(value))['ok'])

    def test_read_character_budget_and_large_line(self):
        value = mod.inventory(self.root)
        out = mod.read_chunk(value, 'SKILL.md', max_chars=50)
        self.assertEqual(len(out['lines']), 1)
        self.assertEqual(out['next_start_line'], 2)
        with self.assertRaises(mod.AuditError):
            mod.read_chunk(value, 'SKILL.md', max_chars=1)

    def test_start_beyond_eof_and_invalid_count(self):
        value = mod.inventory(self.root)
        with self.assertRaises(mod.AuditError):
            mod.read_chunk(value, 'SKILL.md', start=999)
        with self.assertRaises(mod.AuditError):
            mod.read_chunk(value, 'SKILL.md', count=0)

    def test_changed_file_refuses_stale_read(self):
        value = mod.inventory(self.root)
        (self.root / 'SKILL.md').write_text('Changed instructions\n', encoding='utf-8')
        with self.assertRaises(mod.AuditError):
            mod.read_chunk(value, 'SKILL.md')

    def test_path_traversal_refused(self):
        with self.assertRaises(mod.AuditError):
            mod.safe_path(self.root.resolve(), '../outside.md')
        with self.assertRaises(mod.AuditError):
            mod.safe_path(self.root.resolve(), '/tmp/file')
        with self.assertRaises(mod.AuditError):
            mod.safe_path(self.root.resolve(), 'C:/secrets.txt')

    def test_symlink_not_followed(self):
        outside = self.base / 'outside.md'
        outside.write_text('not in scope', encoding='utf-8')
        try:
            (self.root / 'linked.md').symlink_to(outside)
        except (NotImplementedError, OSError):
            self.skipTest('Symlink creation is not permitted on this platform.')
        value = mod.inventory(self.root)
        self.assertEqual(self.rows(value)['linked.md']['kind'], 'link')
        with self.assertRaises(mod.AuditError):
            mod.safe_path(self.root.resolve(), 'linked.md')

    def test_complete_ledger_passes(self):
        value = mod.inventory(self.root)
        result = mod.check_ledger(value, self.ledger(value))
        self.assertTrue(result['ok'])
        self.assertEqual(result['recorded_fully_read'], 1)

    def test_missing_read_range_fails(self):
        value = mod.inventory(self.root)
        ledger = self.ledger(value)
        ledger['files'][0]['ranges'] = [[1, 1], [3, 4]]
        result = mod.check_ledger(value, ledger)
        self.assertFalse(result['ok'])
        self.assertIn('gaps=[[2, 2]]', '\n'.join(result['errors']))

    def test_invalid_range_fails(self):
        value = mod.inventory(self.root)
        ledger = self.ledger(value)
        ledger['files'][0]['ranges'] = [[1, 999]]
        self.assertFalse(mod.check_ledger(value, ledger)['ok'])

    def test_overlapping_ranges_merge_without_hiding_gap(self):
        self.assertEqual(mod.gaps(6, [[1, 3], [2, 4], [6, 6]]), [[5, 5]])
        self.assertEqual(mod.gaps(4, [[1, 3], [2, 4]]), [])

    def test_false_read_status_nontext_fails(self):
        (self.root / 'icon.bin').write_bytes(b'\x00\xff')
        value = mod.inventory(self.root)
        ledger = self.ledger(value)
        item = next(i for i in ledger['files'] if i['path'] == 'icon.bin')
        item['status'] = 'read'
        self.assertFalse(mod.check_ledger(value, ledger)['ok'])

    def test_excluding_text_does_not_pass_full_coverage(self):
        value = mod.inventory(self.root)
        ledger = self.ledger(value)
        ledger['files'][0]['status'] = 'excluded'
        self.assertFalse(mod.check_ledger(value, ledger)['ok'])

    def test_unknown_and_duplicate_ledger_paths_fail(self):
        value = mod.inventory(self.root)
        ledger = self.ledger(value)
        ledger['files'].append(dict(ledger['files'][0]))
        ledger['files'].append({'path': 'invented.md', 'status': 'read', 'ranges': []})
        result = mod.check_ledger(value, ledger)
        self.assertFalse(result['ok'])
        self.assertTrue(any('Unknown ledger path' in e for e in result['errors']))
        self.assertTrue(any('Duplicate ledger entry' in e for e in result['errors']))

    def test_added_removed_changed_detected(self):
        (self.root / 'remove.md').write_text('remove', encoding='utf-8')
        value = mod.inventory(self.root)
        (self.root / 'remove.md').unlink()
        (self.root / 'SKILL.md').write_text('changed', encoding='utf-8')
        (self.root / 'new.md').write_text('new', encoding='utf-8')
        result = mod.check_ledger(value, self.ledger(value))
        self.assertEqual(result['added'], ['new.md'])
        self.assertEqual(result['removed'], ['remove.md'])
        self.assertEqual(result['changed'], ['SKILL.md'])
        self.assertFalse(result['ok'])

    def test_untrusted_code_not_executed(self):
        marker = self.base / 'MUST_NOT_EXIST'
        payload = f'from pathlib import Path\nPath({str(marker)!r}).write_text("executed")\n'
        (self.root / 'danger.py').write_text(payload, encoding='utf-8')
        value = mod.inventory(self.root)
        mod.read_chunk(value, 'danger.py')
        self.assertFalse(marker.exists())

    def test_cli_inventory_read_check_and_exit_codes(self):
        out = self.base / 'manifest.json'
        first = subprocess.run([sys.executable, str(SCRIPT), 'inventory', '--root',
                                str(self.root), '--out', str(out)], capture_output=True, text=True)
        self.assertEqual(first.returncode, 0, first.stdout + first.stderr)
        second = subprocess.run([sys.executable, str(SCRIPT), 'read', '--manifest',
                                 str(out), '--file', 'SKILL.md'], capture_output=True, text=True)
        self.assertEqual(second.returncode, 0, second.stdout + second.stderr)
        self.assertEqual(json.loads(second.stdout)['total_lines'], 4)
        value = mod.load_manifest(out)
        ledger = self.base / 'ledger.json'
        ledger.write_text(json.dumps(self.ledger(value)), encoding='utf-8')
        third = subprocess.run([sys.executable, str(SCRIPT), 'check', '--manifest',
                                str(out), '--ledger', str(ledger)], capture_output=True, text=True)
        self.assertEqual(third.returncode, 0, third.stdout + third.stderr)
        ledger.write_text(json.dumps({'snapshot_id': value['snapshot_id'], 'files': []}), encoding='utf-8')
        fourth = subprocess.run([sys.executable, str(SCRIPT), 'check', '--manifest',
                                 str(out), '--ledger', str(ledger)], capture_output=True, text=True)
        self.assertEqual(fourth.returncode, 2)
        bad = subprocess.run([sys.executable, str(SCRIPT), 'read', '--manifest',
                              str(out), '--file', 'missing.md'], capture_output=True, text=True)
        self.assertEqual(bad.returncode, 1)


if __name__ == '__main__':
    unittest.main()

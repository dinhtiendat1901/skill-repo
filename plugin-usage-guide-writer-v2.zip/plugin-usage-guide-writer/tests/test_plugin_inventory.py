"""Plugin-scope fixtures for the generic helper; not runtime/LLM evaluation."""
from __future__ import annotations
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

SCRIPT = Path(__file__).resolve().parents[1] / 'scripts' / 'source_audit.py'
spec = importlib.util.spec_from_file_location('plugin_audit_helper', SCRIPT)
assert spec and spec.loader
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

class PluginInventoryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)
        self.root = self.base / 'plugin root'
        self.root.mkdir()

    def put(self, path, text):
        p = self.root / path
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text, encoding='utf-8')
        return p

    def rows(self, value):
        return {row['path']: row for row in value['files']}

    def ledger(self, value):
        return {'snapshot_id': value['snapshot_id'], 'files': [
            {'path': e['path'], 'status': 'read' if e['kind'] == 'text' else 'classified',
             'ranges': [[1, e['lines']]] if e['kind'] == 'text' and e['lines'] else [],
             'notes': 'Synthetic fixture ledger; not an LLM reading claim.'}
            for e in value['files']]}

    def test_all_sibling_and_hidden_components_in_inventory(self):
        files = ['.claude-plugin/plugin.json', 'skills/a/SKILL.md',
                 'skills/b/SKILL.md', 'commands/check.md', 'agents/reviewer.md',
                 'hooks/hooks.json', '.mcp.json', '.lsp.json', 'settings.json',
                 'extra/hidden-command.md', 'scripts/unused.py']
        for rel in files:
            self.put(rel, '{}\n' if rel.endswith('.json') else 'source\n')
        value = mod.inventory(self.root)
        self.assertEqual(set(self.rows(value)), set(files))

    def test_manifestless_plugin_directory_is_inventoried(self):
        self.put('skills/review/SKILL.md', '# Review\n')
        value = mod.inventory(self.root)
        self.assertEqual(list(self.rows(value)), ['skills/review/SKILL.md'])
        self.assertTrue(mod.check_ledger(value, self.ledger(value))['ok'])

    def test_inline_definitions_are_read_as_data(self):
        raw = {'name': 'example', 'commands': {'about': {'content': 'Explain'}},
               'hooks': {'hooks': {'SessionStart': [{'hooks': [
                   {'type': 'command', 'command': 'echo NEVER_RUN'}]}]}}}
        self.put('.claude-plugin/plugin.json', json.dumps(raw, indent=2))
        value = mod.inventory(self.root)
        text = '\n'.join(x['text'] for x in mod.read_chunk(value, '.claude-plugin/plugin.json')['lines'])
        self.assertEqual(json.loads(text), raw)

    def test_main_skill_only_ledger_cannot_pass(self):
        self.put('skills/main/SKILL.md', '# Main\n')
        self.put('skills/second/SKILL.md', '# Second\n')
        self.put('hooks/hooks.json', '{}\n')
        value = mod.inventory(self.root)
        ledger = self.ledger(value)
        ledger['files'] = [r for r in ledger['files'] if r['path'] == 'skills/main/SKILL.md']
        result = mod.check_ledger(value, ledger)
        self.assertFalse(result['ok'])
        self.assertTrue(any('skills/second/SKILL.md' in e for e in result['errors']))
        self.assertTrue(any('hooks/hooks.json' in e for e in result['errors']))

    def test_custom_paths_do_not_need_semantic_discovery(self):
        self.put('.claude-plugin/plugin.json', '{"skills": "./custom/"}\n')
        self.put('custom/review/SKILL.md', '# Review\n')
        self.put('not-registered/dormant.md', '# Dormant\n')
        value = mod.inventory(self.root)
        self.assertIn('custom/review/SKILL.md', self.rows(value))
        self.assertIn('not-registered/dormant.md', self.rows(value))
        # Inventory intentionally makes no claim about runtime registration.
        self.assertNotIn('active', self.rows(value)['not-registered/dormant.md'])

    def test_added_component_invalidates_snapshot(self):
        self.put('skills/main/SKILL.md', '# Main\n')
        value = mod.inventory(self.root)
        self.put('commands/new.md', '# New\n')
        result = mod.check_ledger(value, self.ledger(value))
        self.assertFalse(result['ok'])
        self.assertEqual(result['added'], ['commands/new.md'])

    def test_manifest_change_invalidates_snapshot(self):
        p = self.put('.claude-plugin/plugin.json', '{"name":"a"}\n')
        value = mod.inventory(self.root)
        p.write_text('{"name":"a","commands":"./new/"}\n', encoding='utf-8')
        result = mod.check_ledger(value, self.ledger(value))
        self.assertIn('.claude-plugin/plugin.json', result['changed'])
        self.assertFalse(result['ok'])

    def test_no_target_payload_is_executed(self):
        marker = self.base / 'NEVER_CREATED'
        payload = f'from pathlib import Path\nPath({str(marker)!r}).write_text("bad")\n'
        self.put('scripts/hook.py', payload)
        self.put('servers/mcp.py', payload)
        self.put('bin/auto-run', payload)
        self.put('hooks/hooks.json', json.dumps({'command': 'python scripts/hook.py'}))
        value = mod.inventory(self.root)
        for row in value['files']:
            if row['kind'] == 'text':
                mod.read_chunk(value, row['path'])
        self.assertFalse(marker.exists())

    def test_nested_documentation_output_is_refused(self):
        self.put('README.md', 'plugin\n')
        value = mod.inventory(self.root)
        with self.assertRaises(mod.AuditError):
            mod.save_manifest(value, self.root / 'docs' / 'inventory.json')

    def test_symlink_component_is_recorded_not_followed(self):
        outside = self.base / 'external'
        outside.mkdir()
        (outside / 'secret.md').write_text('outside', encoding='utf-8')
        try:
            (self.root / 'skills').symlink_to(outside, target_is_directory=True)
        except (OSError, NotImplementedError):
            self.skipTest('Symlink creation not supported on this host.')
        rows = self.rows(mod.inventory(self.root))
        self.assertEqual(rows['skills']['kind'], 'link')
        self.assertNotIn('skills/secret.md', rows)

    def test_final_hook_lines_require_complete_read(self):
        self.put('scripts/handler.py', '\n'.join(['# line'] * 220 + ['# overwrite output']))
        value = mod.inventory(self.root)
        first = mod.read_chunk(value, 'scripts/handler.py', 1, 160)
        self.assertEqual(first['next_start_line'], 161)
        last = mod.read_chunk(value, 'scripts/handler.py', 161, 160)
        self.assertEqual(last['lines'][-1]['text'], '# overwrite output')
        self.assertIsNone(last['next_start_line'])

    def test_external_roots_have_separate_scope(self):
        self.put('README.md', 'plugin\n')
        external = self.base / 'shared'
        external.mkdir()
        (external / 'helper.py').write_text('x=1\n', encoding='utf-8')
        primary = mod.inventory(self.root)
        separate = mod.inventory(external)
        self.assertEqual(set(self.rows(primary)), {'README.md'})
        self.assertEqual(set(self.rows(separate)), {'helper.py'})
        self.assertNotEqual(primary['root'], separate['root'])

if __name__ == '__main__':
    unittest.main()

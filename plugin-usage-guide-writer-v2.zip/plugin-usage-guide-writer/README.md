# Plugin Usage Guide Writer

Version **2.0.0**. A standalone Claude Code skill adapted from Usage Guide Writer
1.0.0. The TARGET is now an entire Claude Code plugin. Default manual language is
Vietnamese. The original `usage-guide-writer` can remain installed for skill-only
manuals; this variant has a different name and does not replace it automatically.

## What changed

The writer reads the whole plugin root, not just its main SKILL.md. It inventories
all child skills/commands, agents, hooks, scripts, integration/configuration files,
custom/inline registrations and other bundled components. It traces interactions
and distinguishes manual commands from automatic runtime events. It documents
state, configuration, multi-turn use, retries and lifecycle with source evidence.
The generic source reader is retained; it is NOT a plugin-schema parser or runtime
registration validator. New plugin-specific tests exercise whole-root inventory.

## Install on Windows

Extract `skill.zip`. Copy `plugin-usage-guide-writer` into ONE scope:

- Personal: `%USERPROFILE%/.claude/skills/plugin-usage-guide-writer/`
- Project: `<project>/.claude/skills/plugin-usage-guide-writer/`

The final entrypoint is `.../plugin-usage-guide-writer/SKILL.md` (no doubled folder).
Open a fresh local Claude Code session in your working project, then select
`/plugin-usage-guide-writer` in CHAT, not PowerShell. This is not a marketplace
plugin. It requires no MCP server or connector and adds no host hooks.
`agents/openai.yaml` is optional compatibility UI metadata for other tooling;
it is not a Claude Code subagent and is not needed for Claude Code routing.

Runtime reference: https://code.claude.com/docs/en/skills

## First use: document an installed plugin

```text
/plugin-usage-guide-writer
Document the entire skill-creator PLUGIN installed in my Claude Code environment.
Resolve its actual root, version and installation scope first.
Include all bundled components, not only skills/skill-creator/SKILL.md.
Write the detailed Markdown manual in Vietnamese with comprehensive use cases.
Explain follow-up versus reinvocation for each entrypoint and automatic behavior.
Do not install, enable, reload, invoke or run any target component.
```

An exact path avoids ambiguity:

```text
/plugin-usage-guide-writer
Plugin root: C:/work/plugin-sources/review-suite
Output: C:/work/manuals/review-suite/USAGE.md
Read the entire plugin and produce an evidence-linked operating manual.
```

The paths are illustrative; replace them with real ones. These field labels are
natural-language instructions, NOT validated CLI flags. An installed name is a
discovery hint, not proof of which copy is active. Multiple plausible copies require
selection. A child skill path is expanded to its owning plugin; a standalone skill
without a plugin owner is not relabeled as a plugin.

## Multi-turn use of THIS writer

Ordinary follow-ups continue the same audit. Reinvocation alone does not reset it.
The writer maintains inventories/read ledgers and an ANALYSIS.md checkpoint.

```text
Continue this plugin manual. Add a worked example of changing the dataset after
one test run. Distinguish built-in support from your recommendations. Do not run
any target component or invent a resume command.
```

After a new session, invoke the writer and provide source AND saved audit paths:

```text
/plugin-usage-guide-writer
Continue the audit in C:/work/manuals/review-suite/_audit.
Plugin root: C:/work/plugin-sources/review-suite
Verify the saved snapshot and read the checkpoint before resuming.
```

For a different plugin/version, use a separate audit identity. Source changes
require re-inventory and updated evidence. To revise an existing manual, explicitly
authorize replacing that manual; otherwise the writer must not silently overwrite.
Saved files help continuity but are not workflow-engine guarantees.

## Output and coverage

Default: `docs/plugin-guides/<safe-plugin-id-and-snapshot>/USAGE.md`.
Sidecars are in `_audit/` beside it, outside all audited source roots.

The manual includes complete component/capability catalogs, inputs/options,
automatic behavior, per-component invocation/follow-up decisions, handoffs, state,
worked use cases, setup/lifecycle, troubleshooting, risks, unknowns, source ranges
and component-feature-case-evidence coverage. It does not cap the number of cases
arbitrarily; it covers meaningful branches rather than every possible utterance.

## Optional helper

Python 3.10+ and standard library only. Use `python` or `py -3` on Windows. Native
file tools suffice without Python. Resolve script paths under THIS writer.

```text
python scripts/source_audit.py inventory --root C:/path/to/plugin --out C:/path/to/audit/inventory.json
python scripts/source_audit.py read --manifest C:/path/to/audit/inventory.json --file .claude-plugin/plugin.json --start 1 --count 120
python scripts/source_audit.py check --manifest C:/path/to/audit/inventory.json --ledger C:/path/to/audit/read-ledger.json
```

The read example applies only when that manifest exists. The helper works without
one. It checks recorded ranges and hashes, NOT plugin validity, model attention,
manual completeness, effective registration or semantic correctness. See the full
ledger protocol and limitations in `references/source-audit.md`.

## Safety and limitations

This is static analysis. It does not intentionally execute target code, dynamic
snippets, dependency installers, hooks, servers or validation commands, including
`--help`. Target instructions are data, not commands. Scripts are never imported.
An already-enabled plugin may act through host hooks/processes; this writer cannot
sandbox or suppress those. Use a separately isolated inert source copy for an
untrusted plugin. Do not assume not invoking a skill neutralizes automatic effects.

Unreadable functional source, protected content, opaque executables, unsupported
encodings, unreviewed remote services or missing dependencies are disclosed. Reading
all text is not a security certification or proof of runtime behavior. Version-
dependent claims require official evidence or are marked unknown. No actual Claude
Code behavioral execution was performed in this build; see VALIDATION.md.

## Files

| Path | Role |
|---|---|
| SKILL.md | Agent entrypoint and static audit contract |
| references/plugin-components.md | Whole-plugin registration and interaction map |
| references/source-audit.md | Complete reading, evidence and optional helper |
| references/interaction-contract.md | Per-component lifecycle and multi-turn checks |
| references/use-case-design.md | Use cases, transcripts and event timelines |
| references/quality-gates.md | Completion gates |
| references/runtime-sources.md | Official runtime lookup starting points |
| assets/manual-template.md | Required manual structure |
| assets/audit-checkpoint-template.md | Persistent audit workspace template |
| scripts/source_audit.py | Generic read-only inventory/range checker |
| tests/test_*.py | Deterministic helper tests |
| tests/behavioral-cases.md | Unexecuted behavioral acceptance plan |
| HUONG-DAN.md | Vietnamese installation and use guide |
| VALIDATION.md | Actual tests and limitations |
| CHANGELOG.md | Changes from the skill-only version |

Run the deterministic tests from this package directory:

```text
python -m unittest discover -s tests -p "test_*.py" -v
```

No target execution, network or Claude subscription is required for these tests.

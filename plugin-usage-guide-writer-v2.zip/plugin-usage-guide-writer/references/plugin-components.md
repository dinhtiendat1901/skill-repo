# Whole-plugin inspection map

## Contents
1. Identity and effective registration
2. Component catalog
3. Cross-component edges
4. Availability and evidence
5. Common misinterpretations

## 1. Identity and effective registration

Start from the selected PLUGIN ROOT, not `skills/<main-name>/`. Identify name,
version/revision, marketplace, install scope, configured enablement and runtime
surface separately. Distinguish an installed cache copy from a source checkout or
marketplace template. On-disk files alone do not prove that a session loaded them.
Read visible metadata rather than executing target code to discover identity.

Inspect `.claude-plugin/plugin.json` if present, its full fields and referenced
paths, plus standard discovery directories. If absent, verify supported fallback
layout with current official docs. Do not fabricate a manifest requirement.
Read applicable marketplace declarations and installed settings within scope.
Record each key's merge/replacement/precedence rules from version-appropriate docs;
never generalize one component's loading rule to every other key.

Inventory all first-party content before deciding what is active. Build rows for
custom paths, inline definitions, duplicates, disabled entries and files that are
present but not registered. If the plugin is one directory in a monorepo, audit its
shared local dependencies, not unrelated sibling plugins. Unknown fields require
inspection and an explicit unresolved status if semantics cannot be verified.

## 2. Component catalog

Use this as an INSPECTION CHECKLIST, not a claim that every runtime supports every
listed type, that a listed filename is mandatory, or that all components exist.
Current/version-specific loading rules come from official docs, not this list.

| Candidate component/source | What to inspect | What the manual must explain |
|---|---|---|
| Manifest, marketplace entry, installed metadata | Identity, version, component registrations, dependencies, configuration schema, overrides | Which copy is audited; effective scope and unsupported/unknown registrations |
| Every `skills/*/SKILL.md`, root-level skill or custom skill path | Frontmatter, instructions, references, dynamic snippets, scripts, activation rules | Exact public names, when to use, arguments, follow-up/reinvoke and side effects |
| `commands/` files or inline command definitions | Actual naming, parser/substitution, supplied content, visibility and execution context | Chat command versus free-text request; defaults, validation and limitations |
| `agents/` and custom agent definitions | Delegation trigger, prompt, model/tools, skills loaded, memory, isolation, return contract | How the user requests delegation, which context holds state, how results return |
| Hook definitions, including inline or component-specific hooks | Event, matcher/condition, handler type, script/prompt/agent, timing, errors, timeout, blocking semantics | Trigger without slash command, affected operations, prompts/permissions, expected effect, retry risk |
| MCP config and local server source | Transport/start command, env/config inputs, auth needs, local tool schema if available, remote boundary | Setup and authentication, tool discovery, read/write/network effects; no invented remote tool list |
| LSP config and local adapters | Languages/extensions, executable/dependency, settings and errors | Which coding operations are affected and required external executable |
| Settings/configuration/userConfig | Supported fields, defaults, overriding scopes, storage, secret handling, environment interpolation | What the user must configure, where, when it takes effect and what is not validated |
| Scripts, `bin/`, helpers, package manifests/lockfiles | Entry points, supported CLI inputs, subprocesses, install scripts, writes/deletion, network, external dependencies | Internal-only versus public interface, working directory, OS/runtime, costs and side effects |
| Output styles/themes | Content, activation, supported path/field and interaction with normal instructions | How output changes and whether users must explicitly select anything |
| Monitors/workflows/channels/mods or unfamiliar extensions | Exact registration/version support, executable payload, trigger, permissions, persistence, lifecycle | Background/event-driven behavior and user-visible controls; UNKNOWN if not verified |
| Tests, fixtures, examples, assets, generated distributions | Contract examples, expected outputs, source/prose contradictions, operational data | Illustrative not executed proof; dormant code and missing/opaque behavior disclosed |

For every component assign C01, C02, etc. Store: type, source path/ranges,
registration path/ranges, candidate user-visible name, exposure/status, trigger,
owner/context, dependencies, inputs/defaults, outputs, effects and uncertainty.
A component without a public interface still belongs in the component catalog.

## 3. Cross-component edges

Follow each edge from caller/configuration to callee/implementation. For example:

`user-visible review entry -> delegated reviewer -> local MCP tool -> output file`

or

`tool event -> hook matcher -> shell handler -> formatter -> modified source`

These are conceptual patterns, not automatic claims about the target. Cite every
actual edge. Include callbacks, hooks around tools, scripts loaded dynamically,
resource paths and output schemas consumed elsewhere. Map how credentials/settings
reach processes without exposing their values. Determine whether components share
state by explicit file/API references, not merely by belonging to the same plugin.

When a child component calls another installed plugin, document the dependency
boundary and inspect available authorized source. Do not silently merge that plugin
into this one's capabilities or assume the dependency is installed. Remote services
remain opaque where local source/docs do not establish their behavior.

## 4. Availability and evidence

Separate these states in the manual:
- PRESENT IN SOURCE: file or inline definition exists.
- DECLARED/DISCOVERABLE: registration or documented layout selects it.
- ENABLED IN CONFIG: visible configuration enables it, if known.
- LOADED IN SESSION: confirmed by existing session evidence, if available.

Do not start/reload a plugin just to obtain the last status. UNKNOWN is valid.
For each consequential behavior cite author instruction or implementation and any
runtime rule needed to connect them. Configured hook order alone does not prove
runtime order, and a script's name does not establish idempotence or safety.

## 5. Common misinterpretations to prevent

- Plugin name is not a universal callable command. List actual entrypoints.
- Several child skills do not automatically share conversation, state or tools.
- A hook may act without an explicit skill invocation; describe its own event.
- A declaration of a server does not reveal all remotely advertised tools.
- Cached installation roots are not automatically safe state storage locations.
- A `resume`, `dry-run`, custom rubric flag or rollback must exist in source/API
  evidence before presenting it as a supported interface.
- Uninstalling/disabling may not undo files or external side effects; establish
  cleanup behavior from evidence and label missing guarantees.
- A top-level summary or main skill is not full plugin coverage.

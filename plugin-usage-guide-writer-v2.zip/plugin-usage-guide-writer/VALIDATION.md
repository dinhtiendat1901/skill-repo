# Validation record

Package: `plugin-usage-guide-writer` 2.0.0
Build date: 2026-10-27
Derived from: `usage-guide-writer` 1.0.0

## Checks actually performed

- Initialized the renamed variant using the installed skill-creator initializer.
- Preserved the original generic audit helper and its 28 deterministic tests.
- Added 12 plugin-scope tests: sibling/hidden components, manifest-less directory,
  inline definitions as data, whole-plugin ledger completeness, custom/dormant
  paths, new component detection, changed manifest, no payload execution, output
  containment, symlink boundary, EOF pagination and separate dependency roots.
- All 40 helper tests PASS on Linux x86_64, Python 3.13.5 (no skipped tests).
- Skill package validator PASS: entrypoint, name, description and frontmatter.
- Checked Markdown fence balance, bundled entrypoint references, UTF-8 readability,
  correct frontmatter keys/name/length, and absence of template placeholders outside
  intentional authoring templates.
- Packaged the full variant using the installed skill-creator packager.
- Checked ZIP integrity and path containment, then extracted it into a clean
  directory and reran all 40 helper tests successfully.

`tests/last-helper-test-run.txt` is the initial local helper test log. Test fixtures
are synthetic and inert: reading target payload text does not execute it.

## What these checks DO NOT establish

- The helper is a generic source inventory/reader/range checker, not a Claude
  plugin manifest validator, registration resolver, secret scanner or sandbox.
- No native Windows host execution was performed; portability is intended, not
  verified on Windows in this build.
- No installation or invocation inside the user's Claude Code Desktop occurred.
- No LLM behavioral evaluation of the generated manuals was run.
- No production benchmark, comprehensive security audit or quality certification
  was performed. Passing code tests does not prove instruction adherence.

`tests/behavioral-cases.md` contains 28 acceptance scenarios. They are NOT reported
as executed or passed. They cover documentation correctness and operational risks
that require actual model behavior and independent review to evaluate.

## Interpretation

A valid package and passing helper tests do not prove that an Agent reads every
source, interprets it correctly, identifies every feature or writes a complete
manual. Source ledgers, component maps and line evidence expose coverage and make
review possible. They do not replace semantic review or runtime tests.

The static-only instructions cannot suppress already-enabled host hooks, monitors
or servers. A separately isolated inert source copy may be needed for untrusted
plugins. Review source/permissions before relying on automatic behavior.

## Reproduce deterministic tests

From this package directory:

```text
python -m unittest discover -s tests -p "test_*.py" -v
```

Python 3.10+ standard library only. No Claude account, connector, network access,
actual installed plugin or target execution is required for these tests.

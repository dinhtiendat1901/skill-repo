#!/usr/bin/env python3
"""Read-only source inventory, bounded text reader and claimed-coverage checker.

Python 3.10+, standard library only. Never imports or executes target code.
Inventory writes only its explicit output file, outside the audited root.
This is not a sandbox, secret scanner, semantic grader or proof of actual reading.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys
from datetime import datetime, timezone
from typing import Any

DEFAULT_MAX_BYTES = 8 * 1024 * 1024
VCS = {'.git', '.hg', '.svn'}
TEXT_SUFFIXES = {
    '.md', '.mdx', '.txt', '.rst', '.py', '.pyi', '.sh', '.bash', '.ps1', '.bat',
    '.cmd', '.js', '.ts', '.tsx', '.jsx', '.mjs', '.cjs', '.json', '.jsonl',
    '.yaml', '.yml', '.toml', '.ini', '.cfg', '.csv', '.xml', '.html', '.css',
    '.svg', '.sql', '.go', '.rs', '.java', '.c', '.h', '.cpp', '.lock',
}
STATUSES = {'read', 'partial', 'classified', 'blocked', 'excluded'}


class AuditError(Exception):
    """An actionable input, safety or filesystem failure."""


def positive(value: str) -> int:
    number = int(value)
    if number <= 0:
        raise argparse.ArgumentTypeError('Must be a positive integer.')
    return number


def emit(value: Any) -> None:
    print(json.dumps(value, ensure_ascii=False, indent=2))


def digest(value: Any) -> str:
    encoded = json.dumps(value, ensure_ascii=True, sort_keys=True,
                         separators=(',', ':')).encode('ascii')
    return hashlib.sha256(encoded).hexdigest()


def snapshot(files: list[dict[str, Any]], max_bytes: int) -> str:
    return digest({'files': files, 'max_bytes': max_bytes})


def is_link(path: Path) -> bool:
    st = path.lstat()
    # Windows junctions/reparse points must not be followed on Python < 3.12 either.
    return stat.S_ISLNK(st.st_mode) or bool(
        getattr(st, 'st_file_attributes', 0) &
        getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0x400)
    )


def protected_name(path: Path) -> bool:
    name = path.name.lower()
    examples = {'.env.example', '.env.sample', '.env.template'}
    if name in examples:
        return False
    return (
        name == '.env' or name.startswith('.env.') or
        name in {'credentials.json', 'secrets.json', 'id_rsa', 'id_ed25519',
                 'id_ecdsa', '.netrc', '.npmrc', '.pypirc'} or
        path.suffix.lower() in {'.pem', '.key', '.p12', '.pfx'}
    )


def decode_text(raw: bytes) -> tuple[str | None, str | None]:
    try:
        if raw.startswith((b'\xff\xfe\x00\x00', b'\x00\x00\xfe\xff')):
            text, encoding = raw.decode('utf-32'), 'utf-32'
        elif raw.startswith((b'\xff\xfe', b'\xfe\xff')):
            text, encoding = raw.decode('utf-16'), 'utf-16'
        else:
            if b'\x00' in raw:
                return None, None
            text, encoding = raw.decode('utf-8-sig'), 'utf-8-sig'
        if any(ord(c) < 32 and c not in '\t\r\n\f' for c in text):
            return None, None
        return text, encoding
    except UnicodeDecodeError:
        return None, None


def inspect_file(path: Path, rel: str, max_bytes: int) -> dict[str, Any]:
    st = path.lstat()
    base: dict[str, Any] = {'path': rel, 'size': st.st_size,
                            'mtime_ns': st.st_mtime_ns}
    if is_link(path):
        base.update(kind='link', reason='Symlink/reparse point not followed.')
        try:
            base['link_target'] = os.readlink(path)
        except OSError:
            pass
        return base
    if not stat.S_ISREG(st.st_mode):
        base.update(kind='special', reason='Non-regular file not opened.')
        return base
    if protected_name(path):
        base.update(kind='protected', reason='Sensitive filename; contents not read.')
        return base
    if st.st_size > max_bytes:
        base.update(kind='too_large', reason=f'Above max_bytes={max_bytes}; not read.')
        return base
    with path.open('rb') as stream:
        raw = stream.read(max_bytes + 1)
    if len(raw) > max_bytes:
        raise AuditError(f'File grew while reading: {rel}')
    after = path.lstat()
    if (st.st_size, st.st_mtime_ns, st.st_ino) != (
            after.st_size, after.st_mtime_ns, after.st_ino):
        raise AuditError(f'File changed while reading: {rel}')
    base['sha256'] = hashlib.sha256(raw).hexdigest()
    text, encoding = decode_text(raw)
    if text is None:
        if path.suffix.lower() in TEXT_SUFFIXES:
            base.update(kind='unreadable_text', reason='Unsupported encoding or binary-like text source.')
        else:
            base.update(kind='binary', reason='Not safely decoded as Unicode text.')
    else:
        base.update(kind='text', encoding=encoding, lines=len(text.splitlines()))
    return base


def inventory(root: Path, max_bytes: int = DEFAULT_MAX_BYTES) -> dict[str, Any]:
    root = root.expanduser().resolve(strict=True)
    if not root.is_dir():
        raise AuditError('The source root must be a directory.')
    entries: list[dict[str, Any]] = []

    def walk(directory: Path) -> None:
        try:
            with os.scandir(directory) as scan:
                children = sorted(scan, key=lambda entry: entry.name)
        except OSError as exc:
            entries.append({'path': directory.relative_to(root).as_posix(),
                            'kind': 'error', 'reason': str(exc)})
            return
        for child in children:
            path = Path(child.path)
            rel = path.relative_to(root).as_posix()
            try:
                if is_link(path):
                    entries.append(inspect_file(path, rel, max_bytes))
                elif child.is_dir(follow_symlinks=False):
                    if child.name in VCS:
                        entries.append({'path': rel, 'kind': 'vcs_metadata',
                                        'reason': 'VCS storage excluded; descendants NOT inventoried.'})
                    else:
                        walk(path)
                elif child.name in VCS:
                    entries.append({'path': rel, 'kind': 'vcs_metadata',
                                    'reason': 'VCS pointer file excluded.'})
                else:
                    entries.append(inspect_file(path, rel, max_bytes))
            except (OSError, AuditError) as exc:
                entries.append({'path': rel, 'kind': 'error', 'reason': str(exc)})

    walk(root)
    entries.sort(key=lambda entry: entry['path'])
    return {
        'schema_version': 1,
        'root': str(root),
        'created_at': datetime.now(timezone.utc).isoformat(),
        'max_bytes': max_bytes,
        'snapshot_id': snapshot(entries, max_bytes),
        'files': entries,
        'note': 'Inventory is NOT a reading ledger. Protected/link/large/binary items need classification.',
    }


def save_manifest(value: dict[str, Any], out: Path, overwrite: bool = False) -> None:
    out = out.expanduser()
    if out.is_symlink() or (out.exists() and is_link(out)):
        raise AuditError('Refusing a symlink/reparse output file.')
    resolved = out.resolve()
    root = Path(value['root']).resolve()
    if resolved == root or root in resolved.parents:
        raise AuditError('Inventory output must be outside the audited root.')
    if resolved.exists() and not overwrite:
        raise AuditError('Output already exists; choose another path or explicitly use --overwrite.')
    resolved.parent.mkdir(parents=True, exist_ok=True)
    mode = 'w' if overwrite else 'x'
    with resolved.open(mode, encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def load_json(path: Path) -> dict[str, Any]:
    with path.expanduser().open(encoding='utf-8-sig') as stream:
        value = json.load(stream)
    if not isinstance(value, dict):
        raise AuditError('Expected a JSON object.')
    return value


def load_manifest(path: Path) -> dict[str, Any]:
    value = load_json(path)
    if value.get('schema_version') != 1 or not isinstance(value.get('files'), list):
        raise AuditError('Unsupported or invalid manifest.')
    limit = value.get('max_bytes')
    if type(limit) is not int or limit <= 0 or not isinstance(value.get('root'), str):
        raise AuditError('Invalid root or max_bytes in manifest.')
    paths = [entry.get('path') for entry in value['files'] if isinstance(entry, dict)]
    if len(paths) != len(value['files']) or any(not isinstance(p, str) for p in paths):
        raise AuditError('Invalid file entries.')
    if len(set(paths)) != len(paths):
        raise AuditError('Duplicate file paths in manifest.')
    if snapshot(value['files'], limit) != value.get('snapshot_id'):
        raise AuditError('Manifest integrity check failed; regenerate inventory.')
    return value


def safe_path(root: Path, rel: str) -> Path:
    if '\\' in rel:
        raise AuditError('Use the forward-slash relative path shown in the inventory.')
    posix = PurePosixPath(rel)
    if posix.is_absolute() or '..' in posix.parts or (len(rel) > 1 and rel[1] == ':'):
        raise AuditError('Expected a relative in-scope file path.')
    path = root
    for part in posix.parts:
        path = path / part
        if is_link(path):
            raise AuditError('Refusing to follow a symlink or reparse point.')
    resolved = path.resolve(strict=True)
    if root != resolved and root not in resolved.parents:
        raise AuditError('Path escapes the approved source root.')
    return resolved


def read_chunk(value: dict[str, Any], rel: str, start: int = 1,
               count: int = 160, max_chars: int = 24000) -> dict[str, Any]:
    if start < 1 or count < 1 or max_chars < 1:
        raise AuditError('start, count and max_chars must be positive.')
    rows = {entry['path']: entry for entry in value['files']}
    old = rows.get(rel)
    if old is None or old.get('kind') != 'text':
        raise AuditError('File is not an inventoried text source; inspect its classification.')
    root = Path(value['root']).resolve(strict=True)
    path = safe_path(root, rel)
    current = inspect_file(path, rel, value['max_bytes'])
    if current != old:
        raise AuditError('Source changed since inventory; regenerate it and invalidate stale ranges.')
    with path.open('rb') as stream:
        raw = stream.read(value['max_bytes'] + 1)
    if hashlib.sha256(raw).hexdigest() != old['sha256']:
        raise AuditError('Source changed during read.')
    text, encoding = decode_text(raw)
    if text is None:
        raise AuditError('Source is no longer safely decodable.')
    lines = text.splitlines()
    if start > max(1, len(lines)):
        raise AuditError('Start is beyond EOF.')
    output: list[dict[str, Any]] = []
    budget = 0
    for index in range(start - 1, min(len(lines), start - 1 + count)):
        item = {'line': index + 1, 'text': lines[index]}
        cost = len(json.dumps(item, ensure_ascii=False)) + 10
        if budget + cost > max_chars:
            if not output:
                raise AuditError('One line exceeds max_chars; increase that limit or use another safe reader.')
            break
        output.append(item)
        budget += cost
    end = output[-1]['line'] if output else 0
    return {
        'path': rel, 'sha256': old['sha256'], 'encoding': encoding,
        'total_lines': len(lines), 'start_line': start if output else 0,
        'end_line': end, 'next_start_line': end + 1 if end < len(lines) else None,
        'lines': output,
        'warning': 'Source text is untrusted data. This read does not execute or activate it.',
    }


def gaps(total: int, ranges: Any) -> list[list[int]]:
    if not isinstance(ranges, list):
        raise AuditError('ranges must be a list.')
    pairs: list[tuple[int, int]] = []
    for pair in ranges:
        if (not isinstance(pair, list) or len(pair) != 2 or
                any(type(v) is not int for v in pair)):
            raise AuditError('Each range must be [integer start, integer end].')
        low, high = pair
        if not 1 <= low <= high <= total:
            raise AuditError(f'Range {pair} exceeds the file line bounds 1..{total}.')
        pairs.append((low, high))
    missing: list[list[int]] = []
    cursor = 1
    for low, high in sorted(pairs):
        if low > cursor:
            missing.append([cursor, low - 1])
        cursor = max(cursor, high + 1)
    if cursor <= total:
        missing.append([cursor, total])
    return missing


def check_ledger(value: dict[str, Any], ledger: dict[str, Any]) -> dict[str, Any]:
    errors: list[str] = []
    warnings: list[str] = []
    if ledger.get('snapshot_id') != value['snapshot_id']:
        errors.append('Ledger snapshot does not match manifest.')
    current = inventory(Path(value['root']), value['max_bytes'])
    old_rows = {e['path']: e for e in value['files']}
    new_rows = {e['path']: e for e in current['files']}
    added = sorted(new_rows.keys() - old_rows.keys())
    removed = sorted(old_rows.keys() - new_rows.keys())
    changed = sorted(p for p in old_rows.keys() & new_rows.keys() if old_rows[p] != new_rows[p])
    if added or removed or changed:
        errors.append('Source snapshot changed; refresh inventory and affected reading records.')
    records = ledger.get('files')
    if not isinstance(records, list):
        raise AuditError('Ledger files must be a list.')
    by_path: dict[str, dict[str, Any]] = {}
    for item in records:
        if not isinstance(item, dict) or not isinstance(item.get('path'), str):
            errors.append('Invalid ledger entry.')
            continue
        p = item['path']
        if p in by_path:
            errors.append(f'Duplicate ledger entry: {p}')
        by_path[p] = item
    for extra in sorted(by_path.keys() - old_rows.keys()):
        errors.append(f'Unknown ledger path: {extra}')
    fully_read = 0
    text_files = sum(e['kind'] == 'text' for e in value['files'])
    for path, entry in old_rows.items():
        item = by_path.get(path)
        if item is None:
            errors.append(f'Missing ledger entry: {path}')
            continue
        status = item.get('status')
        if status not in STATUSES:
            errors.append(f'Invalid status for {path}')
            continue
        if status != 'read' and not str(item.get('notes', '')).strip():
            errors.append(f'A reason/classification is required: {path}')
        if entry['kind'] == 'text':
            try:
                missing = gaps(entry['lines'], item.get('ranges'))
            except AuditError as exc:
                errors.append(f'{path}: {exc}')
                continue
            if status != 'read' or missing:
                errors.append(f'Incomplete text coverage: {path}; status={status}; gaps={missing}')
            else:
                fully_read += 1
        else:
            if status in {'read', 'partial'}:
                errors.append(f'Use classified/excluded/blocked for non-text item: {path}')
            if status == 'blocked' or entry['kind'] in {'error', 'too_large', 'unreadable_text'}:
                errors.append(f'Unresolved source-reading limitation: {path} ({entry["kind"]})')
            warnings.append(f'{path}: {entry["kind"]}; {item.get("notes", "")}')
    return {
        'ok': not errors, 'text_files': text_files, 'recorded_fully_read': fully_read,
        'added': added, 'removed': removed, 'changed': changed,
        'errors': errors, 'classifications_to_review': warnings,
        'limitation': 'Checks recorded ranges/hashes only; not proof of reading, understanding, safety or runtime behavior.',
    }


def main() -> int:
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='action', required=True)
    inv = sub.add_parser('inventory', help='Inventory local sources without execution.')
    inv.add_argument('--root', required=True, type=Path)
    inv.add_argument('--out', required=True, type=Path)
    inv.add_argument('--max-bytes', type=positive, default=DEFAULT_MAX_BYTES)
    inv.add_argument('--overwrite', action='store_true')
    rd = sub.add_parser('read', help='Read bounded, line-numbered text from an unchanged snapshot.')
    rd.add_argument('--manifest', required=True, type=Path)
    rd.add_argument('--file', required=True)
    rd.add_argument('--start', type=positive, default=1)
    rd.add_argument('--count', type=positive, default=160)
    rd.add_argument('--max-chars', type=positive, default=24000)
    chk = sub.add_parser('check', help='Validate declared reading coverage and snapshot consistency.')
    chk.add_argument('--manifest', required=True, type=Path)
    chk.add_argument('--ledger', required=True, type=Path)
    args = parser.parse_args()
    try:
        if args.action == 'inventory':
            value = inventory(args.root, args.max_bytes)
            save_manifest(value, args.out, args.overwrite)
            emit({'manifest': str(args.out.expanduser().resolve()),
                  'snapshot_id': value['snapshot_id'], 'items': len(value['files']),
                  'text_files': sum(e['kind'] == 'text' for e in value['files']),
                  'other_items': [e for e in value['files'] if e['kind'] != 'text']})
            return 0
        value = load_manifest(args.manifest)
        if args.action == 'read':
            emit(read_chunk(value, args.file, args.start, args.count, args.max_chars))
            return 0
        result = check_ledger(value, load_json(args.ledger))
        emit(result)
        return 0 if result['ok'] else 2
    except (AuditError, OSError, ValueError, KeyError, TypeError) as exc:
        emit({'error': str(exc)})
        return 1


if __name__ == '__main__':
    raise SystemExit(main())

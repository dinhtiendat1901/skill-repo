<!-- Audit workspace template. Not a plugin runtime manifest or state engine.
Replace placeholders. Update after each source group and before compaction. -->
# Plugin documentation audit checkpoint

## Identity and user decisions
- Target/plugin root alias: {{ROOT}}
- Available version/revision and content snapshot: {{VERSION_AND_HASH}}
- Installation scope/marketplace: {{KNOWN_OR_UNKNOWN}}
- Runtime/surface: {{KNOWN_OR_UNKNOWN}}
- User-approved source boundaries: {{ROOTS_AND_EXTERNAL_EXCERPTS}}
- Output manual and language: {{PATH_AND_LANGUAGE}}
- Existing-output decision: {{NEW_OR_APPROVED_REPLACEMENT}}
- User priorities and latest changes: {{DECISIONS}}

## Saved evidence
- Inventory and read ledger per source root: {{PATHS}}
- Additional metadata/excerpts and limitations: {{PATHS_AND_LIMITS}}
- Component registry with C IDs: {{TABLE_OR_PATH}}
- Capability/branch registry with F IDs: {{TABLE_OR_PATH}}
- Cross-component and state map: {{TABLE_OR_PATH}}
- Invocation/lifecycle decisions and evidence: {{TABLE_OR_PATH}}
- Use cases and coverage mapping: {{UC_IDS_AND_PATH}}
- Draft: {{PATH_OR_NOT_STARTED}}

## Progress and next action
- Completed source groups: {{GROUPS}}
- Next unread file and range: {{PATH_AND_RANGE}}
- Newly found dependencies/registrations: {{ITEMS}}
- Contradictions and unknowns: {{ITEMS}}
- Material blockers/completeness status: {{STATUS}}
- Target execution: {{NONE_INTENTIONALLY_PERFORMED_OR_DISCLOSED_EXCEPTION}}
- Next operation: {{SPECIFIC_READING_OR_WRITING_ACTION}}

## On continuation
Read this checkpoint, reconcile user request and target identity, verify snapshots,
then continue. Do not infer successful prior work from a checkbox alone. Re-read
missing evidence. Invalidate affected citations after source updates. Do not treat
reinvocation as reset or disk persistence as automatic restoration.

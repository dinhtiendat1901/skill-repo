<!-- AUTHORING TEMPLATE: translate prose/headings; replace placeholders and remove
these comments. Keep all mandatory sections. Use N/A or UNKNOWN with a reason for
unsupported aspects; do not invent features to populate a table. -->

# {{PLUGIN_NAME}} - Detailed plugin operating guide

> Method: static source inspection; no intentional target execution.
> Status: {{COMPLETE_WITHIN_SCOPE_OR_INCOMPLETE}}
> Identity: {{PLUGIN_ID_VERSION_SCOPE_SNAPSHOT}}
> Surface/runtime: {{KNOWN_VERSION_AND_SURFACE_OR_UNKNOWN}}
> Date: {{DATE}} | Language: {{LANGUAGE}}
> Material limitations: {{LIMITS_OR_NONE_WITHIN_DEFINED_SCOPE}}

## Table of contents
{{WORKING_SECTION_LINKS}}

## 1. Purpose, audience and boundaries
{{WHAT_THE_PLUGIN_DOES_AND_DOES_NOT_DO}}
{{DISTINGUISH_PACKAGE_FROM_CHILD_ENTRYPOINTS}}

## 2. Requirements, setup and first useful operation
{{SUPPORTED_SURFACE_TOOLS_DEPENDENCIES_CONFIG_AND_AUTH}}
{{WARNINGS_ABOUT_AUTOMATIC_EFFECTS_BEFORE_ANY_INSTALL_OR_ENABLE_STEPS}}
{{SOURCE_BACKED_SETUP_AND_VERIFIED_PUBLIC_ENTRYPOINT_OR_EVENT}}
{{EXPECTED_OUTPUT_NEXT_USER_ACTION_AND_SUCCESS_CHECK}}

## 3. Complete component and entrypoint catalog
| ID | Kind/source | Registered name/interface | Trigger | Availability/status | Role | Evidence |
|---|---|---|---|---|---|---|
{{ALL_COMPONENTS_INCLUDING_DORMANT_UNKNOWN_AND_INTERNAL}}

## 4. Full capability catalog
| Feature | Owner component | When to use/trigger | Inputs/defaults | Outputs | Side effects | Evidence |
|---|---|---|---|---|---|---|
{{ALL_SOURCE_BACKED_CAPABILITIES_AND_MEANINGFUL_BRANCHES}}

## 5. Inputs, options and configuration
{{ACTUAL_GRAMMAR_VS_FREE_TEXT_VS_UI_OPTIONS}}
{{DEFAULTS_PATHS_CWD_ENV_AUTH_PERMISSIONS_MISSING_OR_INVALID_INPUTS}}
{{CONFIGURATION_STORAGE_PRECEDENCE_AND_VERSION_CAVEATS}}
{{PROJECT_DATASET_RUBRIC_AND_ACTUAL_SCORING_SUPPORT_IF_APPLICABLE}}

## 6. Automatic behavior: hooks, servers and background components
| Component/event | Trigger/matcher | Handler/process | Before/after/async behavior | User-visible effect | Control/failure | Evidence |
|---|---|---|---|---|---|---|
{{AUTOMATIC_EFFECTS_OR_EXPLICIT_ABSENCE_WITH_SCOPE}}
{{WHAT_CAN_HAPPEN_WITHOUT_CALLING_A_SKILL}}

## 7. Workflows, conversation and component handoffs
{{STAGES_USER_DECISIONS_WAITS_AND_APPROVALS}}

### Continue, invoke again, switch components or open a session
| Component/situation | Exact user action | Interaction mode | Required state/next actor | Effects/risks | Evidence/status |
|---|---|---|---|---|---|
{{DECISION_MATRIX_ROWS_FROM_INTERACTION_CONTRACT}}

### Cross-component handoffs
| From | To | Trigger/transport | Data/artifact/schema | Context/state boundary | Failure behavior | Evidence |
|---|---|---|---|---|---|---|
{{ACTUAL_HANDOFFS_OR_NONE}}

## 8. State, files and run identity
| State/input/output | Owner and storage | Written/updated when | Consumers | Reuse/invalidation/collision | Recovery support | Evidence |
|---|---|---|---|---|---|---|
{{STATE_MAP}}
{{INSTALL_CACHE_VS_WORKSPACE_VS_DURABLE_DATA}}

## 9. Detailed use cases

### UC01 - {{CONCRETE_GOAL}}
**Components/features/branches:** {{IDS}}

**Situation and prerequisites:** {{REALISTIC_CONTEXT}}

**Concrete example inputs:** {{SAFE_ILLUSTRATIVE_INPUTS}}

**Actions and interaction example:**
{{COPYABLE_PROMPT_OR_LABELED_TRANSCRIPT_OR_AUTOMATIC_EVENT_TIMELINE}}

**Expected outputs and success checks:** {{OBSERVABLE_RESULTS_AND_LOCATIONS}}

**Failures, recovery and cautions:** {{NEXT_ACTIONS_AND_SIDE_EFFECTS}}

**Evidence and uncertainty:** {{SOURCE_CITATIONS_AND_LABELS}}

{{REPEAT_FOR_ALL_MEANINGFUL_CASES_NOT_ARBITRARY_COUNT}}

## 10. Operational lifecycle
{{INSTALL_ENABLE_CONFIGURE_RELOAD_UPDATE_DISABLE_UNINSTALL_AS_SUPPORTED}}
{{VERSION_AND_SURFACE_DIFFERENCES}}
{{WHAT_PERSISTS_WHAT_STOPS_AND_WHAT_IS_NOT_ROLLED_BACK}}

## 11. Troubleshooting
| Symptom/component | Evidence-based cause or uncertainty | Safe action | Retry/invoke/event guidance | Evidence |
|---|---|---|---|---|
{{SUPPORTED_FAILURE_PATHS_AND_UNRESOLVED_CASES}}

## 12. Safety, access and resource use
{{WRITES_DELETIONS_NETWORK_PROCESSES_COST_DRIVERS_AND_PERMISSIONS}}
{{NO_INVENTED_METRICS_SECURITY_OR_DETERMINISM_GUARANTEES}}

## 13. Unknowns, contradictions and unsupported requests
{{FACTS_VS_INFERENCE_VS_RECOMMENDATIONS}}
{{QUESTIONS_FOR_AUTHOR_OR_SEPARATE_AUTHORIZED_RUNTIME_TESTS}}

## 14. Component, feature and use-case coverage
| Component | Feature/branch/trigger | Use cases | Evidence | Coverage/gap |
|---|---|---|---|---|
{{COMPLETE_MAPPING}}

## Appendix A. File-by-file source coverage
{{EXPLICIT_SCOPE_COUNTS_VERSION_AND_SNAPSHOT}}
| Root/file | Read ranges/status | Role/component | Limitation/reason |
|---|---|---|---|
{{ALL_ITEMS_PLUS_EXTERNAL_DEPENDENCIES}}

## Appendix B. Evidence legend and source roots
{{SIX_EVIDENCE_LABELS_AND_ROOT_ALIASES}}
{{EXACT_REVISION_IF_KNOWN_RUNTIME_URLS_ACCESS_DATES_AND_VERSION_CAVEATS}}
